import javax.swing.*;
import java.awt.event.ActionEvent;
import java.util.Arrays;

public class KeyboardListener {
    
    //Makes a Window Array for 2 Windows
    private static final Window[] repaintTargets = new Window[2];
    
    //Adds window at i-th spot
    public static void registerRepaintTarget(Window pwind, int i) {
        repaintTargets[i] = pwind;
    }
    
    
    ///////////////////////////////////////////////////
    ///////   Adds KeyBindings to quadwindows    //////
    ///////////////////////////////////////////////////
    public static void addKeyBindings(QuadWindow qwin, String frameName, Rational delta) {
        
        InputMap im = qwin.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap am = qwin.getActionMap();
        
        ////////////////////////////////
        ////// MOVEMENT STUFF   ///////
        ///////////////////////////////
        
        //Zooms camera in/out
        bindKey(im, am, "Q", () -> {
            qwin.R = (2.0)*qwin.R;
            qwin.repaint();
        });
        
        bindKey(im, am, "E", () -> {
            qwin.R = (0.5)*qwin.R;
            qwin.repaint();
        });

        //Moves where the camera is WASD
        bindKey(im, am, "W", () -> {
            qwin.Org.data[1] = (qwin.R/3.0)+(qwin.Org).data[1];
            qwin.repaint();
        });

        bindKey(im, am, "A", () -> {
            qwin.Org.data[0] = -(qwin.R/3.0)+(qwin.Org).data[0];
            qwin.repaint();
        });

        bindKey(im, am, "S", () -> {
            qwin.Org.data[1] = -(qwin.R/3.0)+(qwin.Org).data[1];
            qwin.repaint();
        });
        
        bindKey(im, am, "D", () -> {
            qwin.Org.data[0] = (qwin.R/3.0)+(qwin.Org).data[0];
            qwin.repaint();
        });
        
        
        ////////////////////////////////
        ////// PARTICLE STUFF   ///////
        ///////////////////////////////
        
        
        //Bumps k1 up
        bindKey(im, am, "C", () -> {
            Rational ok1 = qwin.k1;
            
            //Bumps up k1 by 1/10;
            Rational nk1 = ok1.add(ok1, new Rational(1,10));
            qwin.k1 = nk1;
            
            //Repaints
            qwin.repaint();
        });
        
        //Bumps k1 down
        bindKey(im, am, "V", () -> {
            Rational ok1 = qwin.k1;
            
            //Bumps down k1 by 1/10;
            Rational nk1 = ok1.sub(ok1, new Rational(1,10));
            qwin.k1 = nk1;
            
            //Repaints
            qwin.repaint();
        });
        
        //Bumps k2 up
        bindKey(im, am, "B", () -> {
            Rational ok2 = qwin.k2;
            
            //Bumps up k1 by 1/10;
            Rational nk2 = ok2.add(ok2, new Rational(1,10));
            qwin.k2 = nk2;
            
            //Repaints
            qwin.repaint();
        });
        
        //Bumps k2 down
        bindKey(im, am, "N", () -> {
            Rational ok2 = qwin.k2;
            
            //Bumps down k1 by 1/10;
            Rational nk2 = ok2.sub(ok2, new Rational(1,10));
            qwin.k2 = nk2;
            
            //Repaints
            qwin.repaint();
        });
        
        //Repaints only single tile or 3x3 tiles
        bindKey(im, am, "O", () -> {
            Boolean tbool = qwin.onlyone;
            
            //Negates the current state
            tbool = !tbool;
            qwin.onlyone = tbool;
            
            //Repaints
            qwin.repaint();
        });
        
        //Sets back to square
        bindKey(im, am, "R", () -> {
            qwin.k1 = new Rational(0);
            qwin.k2 = new Rational(0);
            
            //Repaints
            qwin.repaint();
        });
        
        //Prints rational pair
        bindKey(im, am, "P", () -> {
            Rational ok1 = qwin.k1;
            Rational ok2 = qwin.k2;
            
            //Makes string
            String toprintstr = "Your rational pair is ("+(ok1.num)+"/"+(ok1.den)+" , "+(ok2.num)+"/"+(ok2.den)+")";
            
            //Prints
            System.out.println(toprintstr);
        });
        

    }
    
    //////////////////////////////////////////////////////////////
    ///////   Adds KeyBindings to windows AND inputwindow   //////
    //////////////////////////////////////////////////////////////
    public static void addKeyBindings(Window win, InputWindow inpwin, String frameName, Rational delta) {

        InputMap im = win.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap am = win.getActionMap();
        
        ////////////////////////////////
        ////// MOVEMENT STUFF   ///////
        ///////////////////////////////
        
        //Zooms camera in/out
        bindKey(im, am, "Q", () -> {
            win.R = (2.0)*win.R;
            win.repaint();
        });
        
        bindKey(im, am, "E", () -> {
            win.R = (0.5)*win.R;
            win.repaint();
        });

        //Moves where the camera is WASD
        bindKey(im, am, "W", () -> {
            win.Org.data[1] = (win.R/3.0)+(win.Org).data[1];
            win.repaint();
        });

        bindKey(im, am, "A", () -> {
            win.Org.data[0] = -(win.R/3.0)+(win.Org).data[0];
            win.repaint();
        });

        bindKey(im, am, "S", () -> {
            win.Org.data[1] = -(win.R/3.0)+(win.Org).data[1];
            win.repaint();
        });
        
        bindKey(im, am, "D", () -> {
            win.Org.data[0] = (win.R/3.0)+(win.Org).data[0];
            win.repaint();
        });
        
        
        ////////////////////////////////
        ////// PARTICLE STUFF   ///////
        ///////////////////////////////
        
        
        ////////////////////////////////////
        ////// CHANGING TIME PARAMETER /////
        ///////////////////////////////////

        
        //Bumps s parameter up
        bindKey(im, am, "T", () -> {
            //Sets windows
            Window tempw1 = repaintTargets[0];
            Window tempw2 = repaintTargets[1];
            //Sets the pairs of particles list of the window in focus
            PointPairs tpplist = win.pplist;
            //First particles
            Particle initp = (tpplist.points1)[0];
            Particle initq = (tpplist.points2)[0];
            //Number of iterates
            int tnoits = tpplist.iterations;
            
            //Click on window1
            if(win == repaintTargets[0]){
                //Pushes up particle on window1 by delta
                Particle nppart = Particle.pushup(initp, delta);
                //Does the dynamics tonits-times
                PointPairs npplist = new PointPairs(nppart, initq, tnoits);
                //Resets new particle lists on both windows, then repaints
                tempw1.pplist = npplist;
                tempw2.pplist = npplist;
                //Repainting both windows
                tempw1.repaint();
                tempw2.repaint();
                
                //Sets the new textfield for affine par1
                Particle newp = (npplist.points1)[0];
                inpwin.pfield1.setText((newp.spar).toString());
                
                //Sets the new textfield for side par1
                inpwin.sfield1.setText(String.valueOf(newp.type));
            }
            //Clicks on window2
            else{
                //Pushes up particle on window2 by delta
                Particle nqpart = Particle.pushup(initq, delta);
                //Does the dynamics tonits-times
                PointPairs npplist = new PointPairs(initp, nqpart, tnoits);
                //Resets new particle lists on both windows, then repaints
                tempw1.pplist = npplist;
                tempw2.pplist = npplist;
                //Repainting both windows
                tempw1.repaint();
                tempw2.repaint();
                
                //Sets the new textfield for affine par2
                Particle newp = (npplist.points2)[0];
                inpwin.pfield2.setText((newp.spar).toString());
                
                //Sets the new textfield for side par2
                inpwin.sfield2.setText(String.valueOf(newp.type));
            }  
            
        });
        
        //Pulls s parameter down
        bindKey(im, am, "R", () -> {
            //Sets windows
            Window tempw1 = repaintTargets[0];
            Window tempw2 = repaintTargets[1];
            //Sets the pairs of particles list of the window in focus
            PointPairs tpplist = win.pplist;
            //First particles
            Particle initp = (tpplist.points1)[0];
            Particle initq = (tpplist.points2)[0];
            //Number of iterates
            int tnoits = tpplist.iterations;
            
            //Click on window1
            if(win == repaintTargets[0]){
                //Pushes up particle on window1 by delta
                Particle nppart = Particle.pullback(initp, delta);
                //Does the dynamics tonits-times
                PointPairs npplist = new PointPairs(nppart, initq, tnoits);
                //Resets new particle lists on both windows, then repaints
                tempw1.pplist = npplist;
                tempw2.pplist = npplist;
                //Repainting both windows
                tempw1.repaint();
                tempw2.repaint();
                
                //Sets the new textfield for affine par1
                Particle newp = (npplist.points1)[0];
                inpwin.pfield1.setText((newp.spar).toString());
                
                //Sets the new textfield for side par1
                inpwin.sfield1.setText(String.valueOf(newp.type));
            }
            //Clicks on window2
            else{
                //Pushes up particle on window2 by delta
                Particle nqpart = Particle.pullback(initq, delta);
                //Does the dynamics tonits-times
                PointPairs npplist = new PointPairs(initp, nqpart, tnoits);
                //Resets new particle lists on both windows, then repaints
                tempw1.pplist = npplist;
                tempw2.pplist = npplist;
                //Repainting both windows
                tempw1.repaint();
                tempw2.repaint();
                
                //Sets the new textfield for affine par2
                Particle newp = (npplist.points2)[0];
                inpwin.pfield2.setText((newp.spar).toString());
                
                //Sets the new textfield for side par2
                inpwin.sfield2.setText(String.valueOf(newp.type));
            }  
        });
        
        
        
        ///////////////////////////////
        ////// CHANGING TORUS k1 /////
        //////////////////////////////
        
        //Bumps k1 parameter up  
        bindKey(im, am, "C", () -> {
            //Sets windows
            Window tempw1 = repaintTargets[0];
            Window tempw2 = repaintTargets[1];
            //Sets the pairs of particles list of the window in focus
            PointPairs tpplist = win.pplist;
            //First particles
            Particle initp = (tpplist.points1)[0];
            Particle initq = (tpplist.points2)[0];
            //Number of iterates
            int tnoits = tpplist.iterations;
            
            //Click on window1
            if(win == repaintTargets[0]){
                //Defines new k1,k2, original anchor, original parameter, and original side
                Rational ok1 = initp.k1;
                Rational nk1 = Rational.add(ok1,delta);
                Rational nk2 = initp.k2;
                //Defines rational for other side
                Rational otherk1 = initq.k1;
                //Checks to see nk1 == ok3, if so, bump up a bit more.
                if(Rational.isequal(nk1, otherk1) == true){
                    System.out.println("k1 = k3 so adding more to k1");
                    nk1 = Rational.add(nk1, delta);
                }
                
                //Runs a convex check 
                Boolean con = Rational.convexcheck(nk1, nk2);
                //If bad change back
                if(con == false){
                    System.out.println("can't change or else not convex");
                    nk1 = ok1;
                }
                
                //Anchors
                int ona = initp.na;
                int oma = initp.ma;
                int oside = initp.type;
                Rational opar = initp.spar;
                //Gets new original direction
                RVector ndir = Particle.ogdir(nk1, nk2, ona, oma, oside);
                //Defines new p-particle
                Particle nppart = new Particle(nk1, nk2, ona, oma, oside, opar, ndir);
                //Does the dynamics tonits-times
                PointPairs npplist = new PointPairs(nppart, initq, tnoits);
                //Resets new particle lists on both windows, then repaints
                tempw1.pplist = npplist;
                tempw2.pplist = npplist;
                //Repainting both windows
                tempw1.repaint();
                tempw2.repaint();
                
                //Sets the new textfield for k1
                inpwin.kfield1.setText(nk1.toString());
            }
            //Clicks on window2
            else{
                //Defines new k1,k2, original anchor, original parameter, and original side
                Rational ok1 = initq.k1;
                Rational nk1 = Rational.add(ok1,delta);
                Rational nk2 = initq.k2;
                //Defines rational for other side
                Rational otherk1 = initp.k1;
                //Checks to see nk1 == otherk1, if so, bump up a bit more.
                if(Rational.isequal(nk1, otherk1) == true){
                    System.out.println("k1 = k3 so adding more to k3");
                    nk1 = Rational.add(nk1, delta);
                }
                
                //Runs a convex check 
                Boolean con = Rational.convexcheck(nk1, nk2);
                //If bad change back
                if(con == false){
                    System.out.println("can't change or else not convex");
                    nk1 = ok1;
                }
                
                //Anchors
                int ona = initq.na;
                int oma = initq.ma;
                int oside = initq.type;
                Rational opar = initq.spar;
                //Gets new original direction
                RVector ndir = Particle.ogdir(nk1, nk2, ona, oma, oside);
                //Defines new p-particle
                Particle nqpart = new Particle(nk1, nk2, ona, oma, oside, opar, ndir);
                //Does the dynamics tonits-times
                PointPairs npplist = new PointPairs(initp, nqpart, tnoits);
                //Resets new particle lists on both windows, then repaints
                tempw1.pplist = npplist;
                tempw2.pplist = npplist;
                //Repainting both windows
                tempw1.repaint();
                tempw2.repaint();
                
                //Sets the new textfield for k3
                inpwin.kfield3.setText(nk1.toString());
            }  
        });
        
        //Pulls back k1 parameter down  
        bindKey(im, am, "V", () -> {
            //Sets windows
            Window tempw1 = repaintTargets[0];
            Window tempw2 = repaintTargets[1];
            //Sets the pairs of particles list of the window in focus
            PointPairs tpplist = win.pplist;
            //First particles
            Particle initp = (tpplist.points1)[0];
            Particle initq = (tpplist.points2)[0];
            //Number of iterates
            int tnoits = tpplist.iterations;
            
            //Click on window1
            if(win == repaintTargets[0]){
                //Defines new k1,k2, original anchor, original parameter, and original side
                Rational ok1 = initp.k1;
                Rational nk1 = Rational.sub(ok1,delta);
                Rational nk2 = initp.k2;
                //Defines rational for other side
                Rational otherk1 = initq.k1;
                
                //Checks to see nk1 == otherk1, if so, bump up a bit more.
                if(Rational.isequal(nk1, otherk1) == true){
                    System.out.println("k1 = k3 so subtracting more from k1");
                    nk1 = Rational.sub(nk1, delta);
                }

                //Runs a convex check 
                Boolean con = Rational.convexcheck(nk1, nk2);
                //If bad change back
                if(con == false){
                    System.out.println("can't change or else not convex");
                    nk1 = ok1;
                }
                
                //Anchors
                int ona = initp.na;
                int oma = initp.ma;
                int oside = initp.type;
                Rational opar = initp.spar;
                //Gets new original direction
                RVector ndir = Particle.ogdir(nk1, nk2, ona, oma, oside);
                //Defines new p-particle
                Particle nppart = new Particle(nk1, nk2, ona, oma, oside, opar, ndir);
                //Does the dynamics tonits-times
                PointPairs npplist = new PointPairs(nppart, initq, tnoits);
                //Resets new particle lists on both windows, then repaints
                tempw1.pplist = npplist;
                tempw2.pplist = npplist;
                //Repainting both windows
                tempw1.repaint();
                tempw2.repaint();
                
                //Sets the new textfield for k1
                inpwin.kfield1.setText(nk1.toString());
            }
            //Clicks on window2
            else{
                //Defines new k1,k2, original anchor, original parameter, and original side
                Rational ok1 = initq.k1;
                Rational nk1 = Rational.sub(ok1,delta);
                Rational nk2 = initq.k2;
                //Defines rational for other side
                Rational otherk1 = initp.k1;
                
                //Checks to see nk1 == otherk1, if so, bump down a bit more.
                if(Rational.isequal(nk1, otherk1) == true){
                    System.out.println("k1 = k3 so subtracting more from k3");
                    nk1 = Rational.sub(nk1, delta);
                }

                //Runs a convex check 
                Boolean con = Rational.convexcheck(nk1, nk2);
                //If bad change back
                if(con == false){
                    System.out.println("can't change or else not convex");
                    nk1 = ok1;
                }
                
                //Anchors
                int ona = initq.na;
                int oma = initq.ma;
                int oside = initq.type;
                Rational opar = initq.spar;
                //Gets new original direction
                RVector ndir = Particle.ogdir(nk1, nk2, ona, oma, oside);
                //Defines new p-particle
                Particle nqpart = new Particle(nk1, nk2, ona, oma, oside, opar, ndir);
                //Does the dynamics tonits-times
                PointPairs npplist = new PointPairs(initp, nqpart, tnoits);
                //Resets new particle lists on both windows, then repaints
                tempw1.pplist = npplist;
                tempw2.pplist = npplist;
                //Repainting both windows
                tempw1.repaint();
                tempw2.repaint();
                
                //Sets the new textfield for k3
                inpwin.kfield3.setText(nk1.toString());
            }  
        });
        
        
        ///////////////////////////////
        ////// CHANGING TORUS k2 /////
        //////////////////////////////
        
        //Bumps k2 parameter up  
        bindKey(im, am, "B", () -> {
            //Sets windows
            Window tempw1 = repaintTargets[0];
            Window tempw2 = repaintTargets[1];
            //Sets the pairs of particles list of the window in focus
            PointPairs tpplist = win.pplist;
            //First particles
            Particle initp = (tpplist.points1)[0];
            Particle initq = (tpplist.points2)[0];
            //Number of iterates
            int tnoits = tpplist.iterations;
            
            //Click on window1
            if(win == repaintTargets[0]){
                //Defines new k1,k2, original anchor, original parameter, and original side
                Rational nk1 = initp.k1;
                Rational ok2 = initp.k2;
                Rational nk2 = Rational.add(ok2,delta);
                //Defines rational for other side
                Rational otherk2 = initq.k2;
                
                //Checks to see nk2 == otherk2, if so, bump up a bit more.
                if(Rational.isequal(nk2, otherk2) == true){
                    System.out.println("k2 = k4 so adding more to k2");
                    nk2 = Rational.add(nk2, delta);
                }

                //Runs a convex check 
                Boolean con = Rational.convexcheck(nk1, nk2);
                //If bad change back
                if(con == false){
                    System.out.println("can't change or else not convex");
                    nk2 = ok2;
                }
                
                //Anchors
                int ona = initp.na;
                int oma = initp.ma;
                int oside = initp.type;
                Rational opar = initp.spar;
                //Gets new original direction
                RVector ndir = Particle.ogdir(nk1, nk2, ona, oma, oside);
                //Defines new p-particle
                Particle nppart = new Particle(nk1, nk2, ona, oma, oside, opar, ndir);
                //Does the dynamics tonits-times
                PointPairs npplist = new PointPairs(nppart, initq, tnoits);
                //Resets new particle lists on both windows, then repaints
                tempw1.pplist = npplist;
                tempw2.pplist = npplist;
                //Repainting both windows
                tempw1.repaint();
                tempw2.repaint();
                
                //Sets the new textfield for k2
                inpwin.kfield2.setText(nk2.toString());
            }
            //Clicks on window2
            else{
                //Defines new k1,k2, original anchor, original parameter, and original side
                Rational nk1 = initq.k1;
                Rational ok2 = initq.k2;
                Rational nk2 = Rational.add(ok2,delta);
                //Defines rational for other side
                Rational otherk2 = initp.k2;
                
                //Checks to see nk2 == otherk2, if so, bump up a bit more.
                if(Rational.isequal(nk2, otherk2) == true){
                    System.out.println("k2 = k4 so adding more to k4");
                    nk2 = Rational.add(nk2, delta);
                }

                //Runs a convex check 
                Boolean con = Rational.convexcheck(nk1, nk2);
                //If bad change back
                if(con == false){
                    System.out.println("can't change or else not convex");
                    nk2 = ok2;
                }
                
                //Anchors
                int ona = initq.na;
                int oma = initq.ma;
                int oside = initq.type;
                Rational opar = initq.spar;
                //Gets new original direction
                RVector ndir = Particle.ogdir(nk1, nk2, ona, oma, oside);
                //Defines new p-particle
                Particle nqpart = new Particle(nk1, nk2, ona, oma, oside, opar, ndir);
                //Does the dynamics tonits-times
                PointPairs npplist = new PointPairs(initp, nqpart, tnoits);
                //Resets new particle lists on both windows, then repaints
                tempw1.pplist = npplist;
                tempw2.pplist = npplist;
                //Repainting both windows
                tempw1.repaint();
                tempw2.repaint();
                
                //Sets the new textfield for k4
                inpwin.kfield4.setText(nk2.toString());
            }  
        });
        
        //Pulls back k2 parameter down  
        bindKey(im, am, "N", () -> {
            
            //Sets windows
            Window tempw1 = repaintTargets[0];
            Window tempw2 = repaintTargets[1];
            //Sets the pairs of particles list of the window in focus
            PointPairs tpplist = win.pplist;
            //First particles
            Particle initp = (tpplist.points1)[0];
            Particle initq = (tpplist.points2)[0];
            //Number of iterates
            int tnoits = tpplist.iterations;
            
            //Click on window1
            if(win == repaintTargets[0]){
                //Defines new k1,k2, original anchor, original parameter, and original side
                Rational nk1 = initp.k1;
                Rational ok2 = initp.k2;
                Rational nk2 = Rational.sub(ok2,delta);
                //Defines rational for other side
                Rational otherk2 = initq.k2;
                
               //Checks to see nk2 == otherk2, if so, bump up a bit more.
                if(Rational.isequal(nk2, otherk2) == true){
                    System.out.println("k2 = k4 so adding more to k2");
                    nk2 = Rational.sub(nk2, delta);
                }

                //Runs a convex check 
                Boolean con = Rational.convexcheck(nk1, nk2);
                //If bad change back
                if(con == false){
                    System.out.println("can't change or else not convex");
                    nk2 = ok2;
                }
                
                //Anchors
                int ona = initp.na;
                int oma = initp.ma;
                int oside = initp.type;
                Rational opar = initp.spar;
                //Gets new original direction
                RVector ndir = Particle.ogdir(nk1, nk2, ona, oma, oside);
                //Defines new p-particle
                Particle nppart = new Particle(nk1, nk2, ona, oma, oside, opar, ndir);
                //Does the dynamics tonits-times
                PointPairs npplist = new PointPairs(nppart, initq, tnoits);
                //Resets new particle lists on both windows, then repaints
                tempw1.pplist = npplist;
                tempw2.pplist = npplist;
                //Repainting both windows
                tempw1.repaint();
                tempw2.repaint();
                
                //Sets the new textfield for k2
                inpwin.kfield2.setText(nk2.toString());
            }
            //Clicks on window2
            else{
                //Defines new k1,k2, original anchor, original parameter, and original side
                Rational nk1 = initq.k1;
                Rational ok2 = initq.k2;
                Rational nk2 = Rational.sub(ok2,delta);
                
                //Defines rational for other side
                Rational otherk2 = initp.k2;
                
                //Checks to see nk2 == otherk2, if so, bump up a bit more.
                if(Rational.isequal(nk2, otherk2) == true){
                    System.out.println("k2 = k4 so adding more to k2");
                    nk2 = Rational.sub(nk2, delta);
                }

                //Runs a convex check 
                Boolean con = Rational.convexcheck(nk1, nk2);
                //If bad change back
                if(con == false){
                    System.out.println("can't change or else not convex");
                    nk2 = ok2;
                }
                
    
                //Anchors
                int ona = initq.na;
                int oma = initq.ma;
                int oside = initq.type;
                Rational opar = initq.spar;
                //Gets new original direction
                RVector ndir = Particle.ogdir(nk1, nk2, ona, oma, oside);
                //Defines new p-particle
                Particle nqpart = new Particle(nk1, nk2, ona, oma, oside, opar, ndir);
                //Does the dynamics tonits-times
                PointPairs npplist = new PointPairs(initp, nqpart, tnoits);
                //Resets new particle lists on both windows, then repaints
                tempw1.pplist = npplist;
                tempw2.pplist = npplist;
                //Repainting both windows
                tempw1.repaint();
                tempw2.repaint();
                
                //Sets the new textfield for k4
                inpwin.kfield4.setText(nk2.toString());
            }  
        });
        
        
        /////////////////////////////////////////////
        ////// PRINTS INFO ABOUT CURRENT WINDOW /////
        /////////////////////////////////////////////
        
        
        
        //Print information
        bindKey(im, am, "P", () -> {
            //Sets windows
            Window tempw1 = repaintTargets[0];
            Window tempw2 = repaintTargets[1];
            //Sets the pairs of particles list of the window in focus
            PointPairs tpplist = win.pplist;
            //First particles
            Particle initp = (tpplist.points1)[0];
            Particle initq = (tpplist.points2)[0];
            //Number of iterates
            int tnoits = tpplist.iterations;
            //Last particles
            Particle lastp = (tpplist.points1)[tnoits-1];
            Particle lastq = (tpplist.points2)[tnoits-1];
            
            //Click on window1
            if(win == repaintTargets[0]){
                //Prints info on initp
                System.out.println("You started at...");
                initp.print();
                System.out.println("");
                System.out.println("");
                //Prints info on lastp
                System.out.println("You ended at...");
                System.out.println("");
                lastp.print();
            }
            //Clicks on window2
            else{
                //Prints info on initq
                System.out.println("You started at...");
                initq.print();
                System.out.println("");
                System.out.println("");
                //Prints info on lastq
                System.out.println("You ended at...");
                System.out.println("");
                lastq.print();
            }  
        });
        
        
        //Prints particle anchors
        bindKey(im, am, "6", () -> {
            //Sets windows
            Window tempw1 = repaintTargets[0];
            Window tempw2 = repaintTargets[1];
            //Sets the pairs of particles list of the window in focus
            PointPairs tpplist = win.pplist;
            //First particles
            Particle initp = (tpplist.points1)[0];
            Particle initq = (tpplist.points2)[0];
            //Number of iterates
            int tnoits = tpplist.iterations;
            //Anchors to print
            String[] toprint1 = tpplist.points1turns;
            String[] toprint2 = tpplist.points2turns;
            
            
            //Click on window1
            if(win == repaintTargets[0]){
                //Prints anchors for 1
                System.out.println("");
                System.out.println("");
                System.out.println("Turns1");
                System.out.println("");
                System.out.println("");
                for(int i = 0; i < (toprint1.length); i++){
                    System.out.println(toprint1[i]);
                }
            }
            //Clicks on window2
            else{
                //Prints anchors for 2
                System.out.println("");
                System.out.println("");
                System.out.println("Turns2");
                System.out.println("");
                System.out.println("");
                for(int i = 0; i < (toprint2.length); i++){
                    System.out.println(toprint2[i]);
                }
            }  
        });
        
        
        
        //Prints particle anchors
        bindKey(im, am, "7", () -> {
            //Sets windows
            Window tempw1 = repaintTargets[0];
            Window tempw2 = repaintTargets[1];
            //Sets the pairs of particles list of the window in focus
            PointPairs tpplist = win.pplist;
            //First particles
            Particle initp = (tpplist.points1)[0];
            Particle initq = (tpplist.points2)[0];
            //Number of iterates
            int tnoits = tpplist.iterations;
            //Anchors to print
            String[] toprint1 = tpplist.points1anchors;
            String[] toprint2 = tpplist.points2anchors;
            
            
            //Click on window1
            if(win == repaintTargets[0]){
                //Prints anchors for 1
                System.out.println("");
                System.out.println("");
                System.out.println("Anchors1");
                System.out.println("");
                System.out.println("");
                for(int i = 0; i < (toprint1.length); i++){
                    System.out.println(toprint1[i]);
                }
            }
            //Clicks on window2
            else{
                //Prints anchors for 2
                System.out.println("");
                System.out.println("");
                System.out.println("Anchors2");
                System.out.println("");
                System.out.println("");
                for(int i = 0; i < (toprint2.length); i++){
                    System.out.println(toprint2[i]);
                }
            }  
        });
        
        
        //Prints particle deltas
        bindKey(im, am, "8", () -> {
            //Sets windows
            Window tempw1 = repaintTargets[0];
            Window tempw2 = repaintTargets[1];
            //Sets the pairs of particles list of the window in focus
            PointPairs tpplist = win.pplist;
            //First particles
            Particle initp = (tpplist.points1)[0];
            Particle initq = (tpplist.points2)[0];
            //Number of iterates
            int tnoits = tpplist.iterations;
            //Anchors to print
            String[] toprint1 = tpplist.points1deltas;
            String[] toprint2 = tpplist.points2deltas;
            
            
            //Click on window1
            if(win == repaintTargets[0]){
                //Prints anchors for 1
                System.out.println("");
                System.out.println("");
                System.out.println("Deltas1");
                System.out.println("");
                System.out.println("");
                for(int i = 0; i < (toprint1.length); i++){
                    System.out.println(toprint1[i]);
                }
            }
            //Clicks on window2
            else{
                //Prints anchors for 2
                System.out.println("");
                System.out.println("");
                System.out.println("Deltas2");
                System.out.println("");
                System.out.println("");
                for(int i = 0; i < (toprint2.length); i++){
                    System.out.println(toprint2[i]);
                }
            }  
        });
        
        //Prints particle sides
        bindKey(im, am, "9", () -> {
            //Sets windows
            Window tempw1 = repaintTargets[0];
            Window tempw2 = repaintTargets[1];
            //Sets the pairs of particles list of the window in focus
            PointPairs tpplist = win.pplist;
            //First particles
            Particle initp = (tpplist.points1)[0];
            Particle initq = (tpplist.points2)[0];
            //Number of iterates
            int tnoits = tpplist.iterations;
            //Anchors to print
            String[] toprint1 = tpplist.points1sides;
            String[] toprint2 = tpplist.points2sides;
            
            
            //Click on window1
            if(win == repaintTargets[0]){
                //Prints anchors for 1
                System.out.println("");
                System.out.println("");
                System.out.println("Sides1");
                System.out.println("");
                System.out.println("");
                for(int i = 0; i < (toprint1.length); i++){
                    System.out.println(toprint1[i]);
                }
            }
            //Clicks on window2
            else{
                //Prints anchors for 2
                System.out.println("");
                System.out.println("");
                System.out.println("Sides2");
                System.out.println("");
                System.out.println("");
                for(int i = 0; i < (toprint2.length); i++){
                    System.out.println(toprint2[i]);
                }
            }  
        });
        
        //Prints particle deltas
        bindKey(im, am, "0", () -> {
            //Sets windows
            Window tempw1 = repaintTargets[0];
            Window tempw2 = repaintTargets[1];
            //Sets the pairs of particles list of the window in focus
            PointPairs tpplist = win.pplist;
            //First particles
            Particle initp = (tpplist.points1)[0];
            Particle initq = (tpplist.points2)[0];
            //Number of iterates
            int tnoits = tpplist.iterations;
            //Anchors to print
            String[] toprint1 = tpplist.points1checks;
            String[] toprint2 = tpplist.points2checks;
            
            
            //Click on window1
            if(win == repaintTargets[0]){
                //Prints anchors for 1
                System.out.println("");
                System.out.println("");
                System.out.println("Checks1");
                System.out.println("");
                System.out.println("");
                for(int i = 0; i < (toprint1.length); i++){
                    System.out.println(toprint1[i]);
                }
            }
            //Clicks on window2
            else{
                //Prints anchors for 2
                System.out.println("");
                System.out.println("");
                System.out.println("Checks2");
                System.out.println("");
                System.out.println("");
                for(int i = 0; i < (toprint2.length); i++){
                    System.out.println(toprint2[i]);
                }
            }  
        });
        

        
    }

    
    
    //Bind Key Method
    private static void bindKey(InputMap im, ActionMap am,
                            String key, Runnable action) {

        String actionKey = key + "Pressed";

        im.put(KeyStroke.getKeyStroke(key), actionKey);

        am.put(actionKey, new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                action.run();
            }
        });
    }
    
}