import java.util.Arrays;

public class PointPairs{
    //Generates a list of point pairs from the data of two particles
    //Number of iterates and pairs of points to return
    public int iterations;
    public Particle[] points1;
    public Particle[] points2;
    
    //Information on the particles
    public String[] points1anchors;
    public String[] points1deltas;
    public String[] points1sides;
    public String[] points1checks;
    public String[] points1turns;
    
    public String[] points2anchors;
    public String[] points2deltas;
    public String[] points2sides;
    public String[] points2checks;
    public String[] points2turns;
    
    //////////////////////////////////////////
    ////// How to construct  point paisr ////
    //////////////////////////////////////////
    
    public PointPairs(Particle ppart1, Particle ppart2, int pits){
        
        //Sets a counter for iterations before breaking
        this.iterations = pits;
        
        //Makes a list of particles parts 
        Particle[][] partpairs = new Particle[iterations][2];
        //Sets initial pair
        partpairs[0] = new Particle[] {ppart1, ppart2};
        
        //Generates #noits pairs using the iteration law
        Particle[] temppoints1 = new Particle[iterations];
        Particle[] temppoints2 = new Particle[iterations];
        
        //Actually generates all the pairs of particles
        Arrays.setAll(partpairs, i -> {
            if(i == 0) {
                return partpairs[0];
            }
            else{
                return Particle.iterate(partpairs[i - 1]);
            }
        });
        
        //Generates the lists of ppoints and qpoints
        Arrays.setAll(temppoints1, i -> partpairs[i][0]);
        Arrays.setAll(temppoints2, i -> partpairs[i][1]);
        
        //Actually sets particle lists
        this.points1 = temppoints1;
        this.points2 = temppoints2;
        
        
        
        
        
        ///////////////////////////////////
        ////// ADDITIONAL INFO POINTS1 ////
        //////////////////////////////////
        
        //Makes an array of sides for 1
        String[] listofsides1 = new String[pits-1];
        Arrays.setAll(listofsides1, i-> String.valueOf(temppoints1[i].type));
        
        
        //Makes an array of changes of na1s and ma1s
        int[] listofdelna1 = new int[pits-1];
        int[] listofdelma1 = new int[pits-1];
        Arrays.setAll(listofdelna1, i -> (temppoints1[i+1].na - temppoints1[i].na));
        Arrays.setAll(listofdelma1, i -> (temppoints1[i+1].ma - temppoints1[i].ma));
        
        //Makes vectors from them
        RVector kvec1 = new RVector(ppart1.k1, ppart1.k2);
        RVector[] part1dels = new RVector[pits-1];
        Arrays.setAll(part1dels, i -> new RVector(listofdelna1[i], listofdelma1[i]));
        Rational[] dots1 = new Rational[pits-1];
        Arrays.setAll(dots1, i -> RVector.dot(part1dels[i], kvec1));
        String[] checks1 = new String[pits-1];
        Arrays.setAll(checks1, i -> String.valueOf(Rational.pos(dots1[i])));
        
        //Sets anchors
        String[] anchors1 = new String[pits];
        Arrays.setAll(anchors1, i -> ("("+(temppoints1[i].na)+" , "+(temppoints1[i].ma)+")"));
        this.points1anchors = anchors1;
        
        //Sets deltas
        String[] deltas1 = new String[pits-1];
        Arrays.setAll(deltas1, i -> ("("+((temppoints1[i+1].na)-(temppoints1[i].na))+" , "+((temppoints1[i+1].ma)-(temppoints1[i].ma))+")"));
        this.points1deltas = deltas1;
        
        //Sets sides
        this.points1sides = listofsides1;
        
        //Sets turns
        int[] sidechanges1 = new int[pits-1];
        Arrays.setAll(sidechanges1, i -> (temppoints1[i+1].type - temppoints1[i].type));
        String[] rfl1 = new String[pits-1];
        Arrays.setAll(rfl1, i ->{
            if(sidechanges1[i] == 1){
                return "R";
            }
            else if(sidechanges1[i] == 0){
                return "F";
            }
            else{
                return "L";
            }
        });
        this.points1turns = rfl1;
        
        //Sets checks
        this.points1checks = checks1;
        
        //////////////////////////////////
        ////// ADDITIONAL INFO POINTS2////
        /////////////////////////////////
        
        //Makes an array of changes of na2s and ma2s
        int[] listofdelna2 = new int[pits-1];
        int[] listofdelma2 = new int[pits-1];
        Arrays.setAll(listofdelna2, i -> (temppoints2[i+1].na - temppoints2[i].na));
        Arrays.setAll(listofdelma2, i -> (temppoints2[i+1].ma - temppoints2[i].ma));
        
        //Makes an array of sides for 2
        String[] listofsides2 = new String[pits-1];
        Arrays.setAll(listofsides2, i-> String.valueOf(temppoints2[i].type));
        
        //Makes vectors from them
        RVector kvec2 = new RVector(ppart2.k1, ppart2.k2);
        RVector[] part2dels = new RVector[pits-1];
        Arrays.setAll(part2dels, i -> new RVector(listofdelna2[i], listofdelma2[i]));
        Rational[] dots2 = new Rational[pits-1];
        Arrays.setAll(dots2, i -> RVector.dot(part2dels[i], kvec2));
        String[] checks2 = new String[pits-1];
        Arrays.setAll(checks2, i -> String.valueOf(Rational.pos(dots2[i])));
        
        //Sets anchors
        String[] anchors2 = new String[pits];
        Arrays.setAll(anchors2, i -> ("("+(temppoints2[i].na)+" , "+(temppoints2[i].ma)+")"));
        this.points2anchors = anchors2;
        
        //Sets deltas
        String[] deltas2 = new String[pits-1];
        Arrays.setAll(deltas2, i -> ("("+((temppoints2[i+1].na)-(temppoints2[i].na))+" , "+((temppoints2[i+1].ma)-(temppoints2[i].ma))+")"));
        this.points2deltas = deltas2;
        
        //Sets sides
        this.points2sides = listofsides2;
        
        //Sets turns
        int[] sidechanges2 = new int[pits-1];
        Arrays.setAll(sidechanges2, i -> (temppoints2[i+1].type - temppoints2[i].type));
        String[] rfl2 = new String[pits-1];
        Arrays.setAll(rfl2, i ->{
            if(sidechanges2[i] == -1){
                return "R";
            }
            else if(sidechanges2[i] == 0){
                return "F";
            }
            else{
                return "L";
            }
        });
        this.points2turns = rfl2;
        
        //Sets checks
        this.points2checks = checks2;

    }
    
    
}