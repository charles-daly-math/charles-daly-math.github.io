import java.awt.*;
import java.awt.Color;
import java.awt.event.*;
import javax.swing.*;
import java.awt.geom.*;
import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

public class Window extends JPanel implements MouseListener{
    
    ///////////////////////////////////
    //THIS IS ALL SCREEN/WINDOW STUFF//
    ///////////////////////////////////
    
    //Some variables defining the frame
    public static double screensize = 700.0;
    public double R;
    public Vector Org;
    
    //Parameters k1, k2, list of pairs of particles, and a left/right window boolean
    public Rational k1;
    public Rational k2;
    public PointPairs pplist;
    public Boolean lor;
    
    //Adding stuff to window for rational pair k1, k2
    public Window(Rational pk1, Rational pk2, Boolean plor){
        this.addMouseListener(this);
        this.setBackground(Color.WHITE);
        this.setPreferredSize(new Dimension((int) screensize, (int) screensize));
        
        //Rationals for developing grid
        this.k1 = pk1;
        this.k2 = pk2;
        
        //Boolean for left or right particles
        this.lor = plor;
    }
    
 
    
    //Defining java coordinates from vector coordinates
    public static double[] jc(Vector v, double s, Vector o){
        return new double[] {(((v.data[0]-o.data[0])/s)+1)*(screensize/2), (1-((v.data[1]-o.data[1])/s))*(screensize/2)};
    }
    

    //Method for telling java coordinates
    public void print(double[] jc){
        System.out.println("Java coordinates are: ("+jc[0]+","+jc[1]+")");
    }
    
    
    //Defining vector coordinates from java coordinates
    public static Vector vc(double x, double y, double s, Vector o){
        return new Vector(new double[] {((2*x/screensize)-1)*s+o.data[0], ((-2*y/screensize)+1)*s+o.data[1]});
    }
    
    
    
    ////////////////////////////////////
    //THIS IS ALL DRAWING SHAPES STUFF//
    ///////////////////////////////////
    
    ////////////////////
    /////  LINES    ////
    ////////////////////
    
    //Draws a line between two points in vector coordinates
    public void drawLine(Graphics2D g, Vector v, Vector w){
        g.draw(new Line2D.Double(jc(v, R, Org)[0],jc(v, R, Org)[1],jc(w, R, Org)[0],jc(w, R, Org)[1]));
    }
    
    //Draws a line between two points in vector coordinates in color C
    public void drawLine(Graphics2D g, Vector v, Vector w, Color C){
        g.setColor(C);
        g.draw(new Line2D.Double(jc(v, R, Org)[0],jc(v, R, Org)[1],jc(w, R, Org)[0],jc(w, R, Org)[1]));
    }
    
    /////////////////////////////////////
    /////  LINES FOR NEW CLASSES    ////
    /////////////////////////////////////
    
    //Draw line from two RVecs in vector coordinates
    public void drawLine(Graphics2D g, RVector v, RVector w){
        drawLine(g, v.vapp, w.vapp);
    }
    
    //Draw line from two RVecs in vector coordinates in Color C
    public void drawLine(Graphics2D g, RVector v, RVector w, Color C){
        g.setColor(C);
        drawLine(g, v.vapp, w.vapp);
    }
    
    //Draw line from two Particles in vector coordinates
    public void drawLine(Graphics2D g, Particle p1, Particle p2){
        drawLine(g, p1.coords, p2.coords);
    }
    
    //Draw line from two Particles in vector coordinates in Color C
    public void drawLine(Graphics2D g, Particle p1, Particle p2, Color C){
        g.setColor(C);
        drawLine(g, p1.coords, p2.coords);
    }
    
    
    
    
    ////////////////////
    /////  RAYS    ////
    ////////////////////
    
    //Draws a ray at point p pointed in vector v
    public void drawRay(Graphics2D g, Vector p, Vector v){
        g.draw(new Line2D.Double(jc(p, R, Org)[0],jc(p, R, Org)[1],jc(p.plus(p,v), R, Org)[0],jc(p.plus(p,v), R, Org)[1]));
    }
    
    //Draws a ray a point p pointed in vector v in color C
    public void drawRay(Graphics2D g, Vector p, Vector v, Color C){
        g.setColor(C);
        g.draw(new Line2D.Double(jc(p, R, Org)[0],jc(p, R, Org)[1],jc(p.plus(p,v), R, Org)[0],jc(p.plus(p,v), R, Org)[1]));
    }
    
     //////////////////////////////////
    /////  RAYS FOR NEW CLASSES    ////
    //////////////////////////////////
    
    //Draw a ray from RVec directed in v RVec
    public void drawRay(Graphics2D g, RVector p, RVector w){
        drawRay(g, p.vapp, w.vapp);
    }
    
    //Draws a ray a point p pointed in Rvector v in color C
    public void drawRay(Graphics2D g, RVector p, RVector v, Color C){
        g.setColor(C);
        drawRay(g, p.vapp, v.vapp, C);
    }
    
    //Draws a ray a Particle p pointed in Rvector v in color C
    public void drawRay(Graphics2D g, Particle p1, RVector v, Color C){
        g.setColor(C);
        drawRay(g, (p1.coords), v, C);
    }
    
    //Draws a ray a Particle p pointed in Rvector v 
    public void drawRay(Graphics2D g, Particle p1, RVector v){
        drawRay(g, p1.coords, v);
    }
    
    
    /////////////////////
    /////  SHAPES    ////
    /////////////////////
    
    //Draw a point in vector coordinates
    public void drawPoint(Graphics2D g, Vector v){
        drawLine(g, v, v);
    }
    
    //Draws a circle with coordinates x,y and radius r (java does diameter)
    public void drawCircle(Graphics2D g, Vector v, Double rad){
        g.draw(new Ellipse2D.Double(jc(v, R, Org)[0] - ((rad)/R)*(screensize/2) , jc(v, R, Org)[1] - ((rad)/R)*(screensize/2), (rad/R)*(screensize), (rad/R)*(screensize)));
    }
    
   //Draws a circle at RVector rv, with radius r
    public void drawCircle(Graphics2D g, RVector rv, Double rad){
        drawCircle(g, rv.vapp, rad);
    }
    
    //Draws a circle at RVector rv, with radius r with color C
    public void drawCircle(Graphics2D g, RVector rv, Double rad, Color C){
        g.setColor(C);
        drawCircle(g, rv.vapp, rad);
    }
    
    //Draws a circle at Particle p, with radius r with color C
    public void drawCircle(Graphics2D g, Particle p, Double rad, Color C){
        g.setColor(C);
        drawCircle(g, p.coords, rad);
    } 
    
    //Paint
    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                             RenderingHints.VALUE_ANTIALIAS_ON);
        
        ////////////////////////////////////////
        ///// ACTUALLY PAINTING THINGS    //////
        ////////////////////////////////////////
        
        
        
        
        //////////////////////////////////
        /////  PAINTING THE GRID    //////
        //////////////////////////////////
        
        //Test particle for accessing methods
        Particle testP = new Particle(k1, k2);
        
        //Outer bound of minus and plus tiles
        int nop = pplist.iterations;
        
        //Sets left/right particles
        Particle[] leftparts = (pplist.points1);
        Particle[] rightparts = (pplist.points2);
        
        //Gets the vertices
        RVector[][] quadsofvertices = new RVector[nop][4];
        
        //If boolean is true, then defines left side particles
        if(lor == true){
            Arrays.setAll(quadsofvertices,
                i -> {
                    RVector[] temp = new RVector[4];
                    //Anchor
                    int tna = leftparts[i].na;
                    int tma = leftparts[i].ma;
                    //Declaring the vertices in cc order
                    temp[0] = leftparts[i].y0;
                    temp[1] = leftparts[i].y1;
                    temp[2] = leftparts[i].y2;
                    temp[3] = leftparts[i].y3;
                    //Returns temp;
                    return temp;
                }
            );
        }
        
        //If boolean is false, then defines the right side particles
        else{
            Arrays.setAll(quadsofvertices,
                i -> {
                    RVector[] temp = new RVector[4];
                    //Anchor
                    int tna = rightparts[i].na;
                    int tma = rightparts[i].ma;
                    //Declaring the vertices in cc order
                    temp[0] = rightparts[i].y0;
                    temp[1] = rightparts[i].y1;
                    temp[2] = rightparts[i].y2;
                    temp[3] = rightparts[i].y3;
                    //Returns temp;
                    return temp;
                }
            );
        }
        
        
        //Only does this the below if nop > 1
        if(nop > 1){
            //Draws next 3 line segments depending on which move you made 
            for(int i=1; i < nop; i++){
                //Line Segments at a larger stroke
                g2.setStroke(new BasicStroke(2));
                drawLine(g2, quadsofvertices[i][1], quadsofvertices[i][2], Color.BLACK);
                drawLine(g2, quadsofvertices[i][2], quadsofvertices[i][3], Color.BLACK);
                drawLine(g2, quadsofvertices[i][3], quadsofvertices[i][0], Color.BLACK);
                //Circles
                drawCircle(g2, quadsofvertices[i][2], 0.01, Color.BLUE);
                drawCircle(g2, quadsofvertices[i][3], 0.01, Color.BLUE); 
            }
            
            
            //Line Segments at a normal stroke
            g2.setStroke(new BasicStroke(1));
            
            //if boolean true, draw left side iterates
            if(lor == true){
                for(int i = 1; i < (nop-1); i++){
                    drawLine(g2, leftparts[i], leftparts[i+1], Color.BLACK);
                    drawCircle(g2, leftparts[i], 0.02, Color.RED);
                }
                
                //Draws first in magenta
                drawLine(g2, leftparts[0], leftparts[1], Color.BLACK);
            }
            
            //if boolean false, draw right side iterates
            else{
                for(int i = 1; i < (nop-1); i++){
                    drawLine(g2, rightparts[i], rightparts[i+1], Color.BLACK);
                    drawCircle(g2, rightparts[i], 0.02, Color.RED);
                }

                //Draws first in magenta
                drawLine(g2, rightparts[0], rightparts[1], Color.BLACK);
            }
        }
        
        //Draws first and last circles in magenta / orange respectively
        //If left particle
        if(lor == true){
            drawCircle(g2, leftparts[0], 0.4, Color.MAGENTA);
            drawCircle(g2, leftparts[nop-1], 0.4, Color.ORANGE);
        }
        //If right particle
        else{
            drawCircle(g2, rightparts[0], 0.4, Color.MAGENTA);
            drawCircle(g2, rightparts[nop-1], 0.4, Color.ORANGE);
        }
        
        
        //Draws first full tile
        drawLine(g2, quadsofvertices[0][0], quadsofvertices[0][1], Color.BLACK);
        drawLine(g2, quadsofvertices[0][1], quadsofvertices[0][2], Color.BLACK);
        drawLine(g2, quadsofvertices[0][2], quadsofvertices[0][3], Color.BLACK);
        drawLine(g2, quadsofvertices[0][3], quadsofvertices[0][0], Color.BLACK);
        
        //Draws first full vertices in green
        drawCircle(g2, quadsofvertices[0][0], 0.01, Color.GREEN);
        drawCircle(g2, quadsofvertices[0][1], 0.01, Color.GREEN);
        drawCircle(g2, quadsofvertices[0][2], 0.01, Color.GREEN);
        drawCircle(g2, quadsofvertices[0][3], 0.01, Color.GREEN);
        

//        //Draws a line perpendicular to the parameter vector
//        RVector perpvec = new RVector(Rational.neg(k2),k1);
//        perpvec = RVector.scale(new Rational(100), perpvec);
//        drawLine(g2, RVector.neg(perpvec), perpvec, Color.GREEN);
//        
//        //Draws a line parallel to the parameter vector
//        RVector parvec = new RVector(k1,k2);
//        parvec = RVector.scale(new Rational(100), parvec);
//        drawLine(g2, RVector.neg(parvec), parvec, Color.RED);
                
        //////////////////////////////
        ////// DRAWS  ITERATES////////
        //////////////////////////////
        
        //if boolean true, draw left side iterates
//        if(lor == true){
//            for(int i = 1; i < (nop-1); i++){
//                drawLine(g2, leftparts[i], leftparts[i+1], Color.BLACK);
//                drawCircle(g2, leftparts[i], 0.02, Color.RED);
//            }

//            //Draws first in magenta
//            drawLine(g2, leftparts[0], leftparts[1], Color.BLACK);
//            drawCircle(g2, leftparts[0], 0.02, Color.MAGENTA);
//        }
//        //if boolean false, draw right side iterates
//        else{
//            for(int i = 1; i < (nop-1); i++){
//                drawLine(g2, rightparts[i], rightparts[i+1], Color.BLACK);
//                drawCircle(g2, rightparts[i], 0.02, Color.RED);
//            }
//
//            //Draws first in magenta
//            drawLine(g2, rightparts[0], rightparts[1], Color.BLACK);
//            drawCircle(g2, rightparts[0], 0.02, Color.MAGENTA);
//        }
        
    }
    
    
    //Mouse commands
    public void mouseClicked(MouseEvent e){
        //Tells you where you click
        Vector v = vc(e.getX(), e.getY(), R, Org);
        Vector w = new Vector(new double[] {v.data[0], v.data[1]});
        w.print();
    }
        
    public void mousePressed(MouseEvent e){}
    public void mouseEntered(MouseEvent e){}
    public void mouseExited(MouseEvent e){}
    public void mouseReleased(MouseEvent e){}
    
}