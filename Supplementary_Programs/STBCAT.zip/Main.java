import java.awt.*;
import javax.swing.*;
import java.util.*;

public class Main extends JPanel{

    public static void main(String[] args){
        
        ////////////////////////////////
        /// MAKES FIRST WINDOW ////////
        ////////////////////////////////


        //Makes frames, windows, input windows, and keyboard listeners
        JFrame frame1 = new JFrame("This is the first tiling");

        ////////////////////////////////////////////
        /// DECLARING RATIONALS AND PARTICLES ////////
        ////////////////////////////////////////////

        //Declaring initial parameters for tile 1
        Rational k1 = new Rational(0,10);
        Rational k2 = new Rational(0,10);

        //Declaring initial parameters for tile 2     
        Rational k3 = new Rational(1,1);
        Rational k4 = new Rational(1,4);

        //Declaring initial anchors for both tiles
        int an1 = 0;
        int am1 = 0;
        int an2 = 0;
        int am2 = 0;

        //Declaring initial sides
        int side1 = 1;
        int side2 = 1;

        //(these need to be between 0 and 1 strictly!)
        //      Declaring initial parameters 
        //(these need to be between 0 and 1 strictly!)
        Rational ip1 = new Rational(1,2);
        Rational ip2 = new Rational(1,2);

        //Declaring initial directions
        RVector initdir1 = Particle.ogdir(k1, k2, an1, am1, side1);
        RVector initdir2 = Particle.ogdir(k3, k4, an2, am2, side2);

        //Declaring of to iteratations
        int noits = 100;
        
        


        //Makes the particles
        Particle p1 = new Particle(k1, k2, an1, am1, side1, ip1, initdir1);
        Particle q1 = new Particle(k3, k4, an2, am2, side2, ip2, initdir2);
        

        //Constructs the pairs of points over the iterations
        PointPairs init = new PointPairs(p1, q1, noits);    
        
        

        ////////////////////////////////////////
        ///////// DONE MAKING PARTICLES ////////
        ////////////////////////////////////////

        //Sets scales for window
        Window window1 = new Window(k1, k2, true);
        window1.R = 2.5;
        window1.Org = new Vector(new double[] {0.0,0.0});




        ////////////////////INTRODUCES PARTICLES\\\\\\\\\
        Rational pdelt = new Rational(1,10);
        window1.pplist = init;
        /////////////////////////////////////////////////

        //Adds some stuff above to frame1.
        frame1.add(window1);
        frame1.setContentPane(window1);
        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame1.pack();
        frame1.setVisible(true);
        frame1.setResizable(false);

        //Adds where the first frame is
        frame1.setLocation((int) (2.175*(window1.screensize)),0);








        ////////////////////////////////
        /// MAKES SECOND WINDOW ////////
        ////////////////////////////////

        //Just does the same for another window
        JFrame frame2 = new JFrame("This is the second tiling");

        //Sets scales for window
        Window window2 = new Window(k3, k4, false);
        window2.R = 2.5;
        window2.Org = new Vector(new double[] {0.0,0.0});



        ////////////////////INTRODUCES PARTICLES\\\\\\\\\
        window2.pplist = init;
        /////////////////////////////////////////////////

        //Adds some stuff above to frame2.
        frame2.add(window2);
        frame2.setContentPane(window2);
        frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame2.pack();
        frame2.setVisible(true);
        frame2.setResizable(false);


        //Adds where the second frame is
        frame2.setLocation((int) (3.175*(window1.screensize)),0);




        ///////////////////////////////////
        //////// MAKES QUAD WINDOW ////////
        //////////////////////////////////

        JFrame frame3 = new JFrame("This is a quad window");
        
        //Sets scales for window
        QuadWindow qwindow1 = new QuadWindow(new Rational(0,1), new Rational(0,1), false);
        qwindow1.R = 2.5;
        qwindow1.Org = new Vector(new double[] {0.0,0.0});

        
        //Adds some stuff above to frame3.
        frame3.add(qwindow1);
        frame3.setContentPane(qwindow1);
        frame3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame3.pack();
        frame3.setVisible(true);
        frame3.setResizable(false);
        
        //Adds where the third frame is
        frame3.setLocation((int) (4.175*(window1.screensize)), 0);
        
        
        
        /////////////////////////////////////////////////

        /////////////////////////////////////
        //////// MAKES INPUT WINDOW ////////
        ////////////////////////////////////
        //Just does the same for another window
        JFrame frame4 = new JFrame("This is control panel");
        //Input window
        InputWindow iw = new InputWindow(p1, q1, noits);
        iw.win1 = window1;
        iw.win2 = window2;
        frame4.add(iw);
        frame4.setContentPane(iw);
        frame4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame4.pack();
        frame4.setVisible(true);
        frame4.setResizable(false);
        frame4.setLocation((int) (2.175*(window1.screensize)),(int) (1.075*(window1.screensize)));
        
        
        
        
        //////////////////////////////////////////////////
        //////// ADDS KEYBOARD LISTENER TO STUFF    ////////
        /////////////////////////////////////////////////
        KeyboardListener.registerRepaintTarget(window1, 0);
        KeyboardListener.addKeyBindings(window1, iw, "Frame1", pdelt);
        
        KeyboardListener.registerRepaintTarget(window2, 1);
        KeyboardListener.addKeyBindings(window2, iw, "Frame2", pdelt);
        
        KeyboardListener.addKeyBindings(qwindow1, "Frame3", pdelt);
  
    }
    
    
    
    

    
}
