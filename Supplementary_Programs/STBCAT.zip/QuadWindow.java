import java.awt.*;
import java.awt.Color;
import java.awt.event.*;
import javax.swing.*;
import java.awt.geom.*;
import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

public class QuadWindow extends JPanel implements MouseListener{
    
    ///////////////////////////////////
    //THIS IS ALL SCREEN/WINDOW STUFF//
    ///////////////////////////////////
    
    //Some variables defining the frame
    public static double screensize = 500.0;
    public double R;
    public Vector Org;
    
    //Parameters k1, k2, list of pairs of particles, and a left/right window boolean
    public Rational k1;
    public Rational k2;
    public Boolean onlyone;

    //Adding stuff to window for rational pair k1, k2
    public QuadWindow(Rational pk1, Rational pk2, Boolean ptype){
        this.addMouseListener(this);
        this.setBackground(Color.WHITE);
        this.setPreferredSize(new Dimension((int) screensize, (int) screensize));
        
        //Rationals for developing grid
        this.k1 = pk1;
        this.k2 = pk2;
        
        //Boolean for grid or only one
        this.onlyone = ptype;
    }
    
 
    
    //Defining java coordinates from vector coordinates
    public static double[] jc(Vector v, double s, Vector o){
        return new double[] {(((v.data[0]-o.data[0])/s)+1)*(screensize/2), (1-((v.data[1]-o.data[1])/s))*(screensize/2)};
    }
    

    //Method for telling java coordinates
    public void print(double[] jc){
        System.out.println("Java coordinates are: ("+jc[0]+","+jc[1]+")");
    }
    
    
    //Defining vector coordinates from java coordinates
    public static Vector vc(double x, double y, double s, Vector o){
        return new Vector(new double[] {((2*x/screensize)-1)*s+o.data[0], ((-2*y/screensize)+1)*s+o.data[1]});
    }
    
    
    
    ////////////////////////////////////
    //THIS IS ALL DRAWING SHAPES STUFF//
    ///////////////////////////////////
    
    ////////////////////
    /////  LINES    ////
    ////////////////////
    
    //Draws a line between two points in vector coordinates
    public void drawLine(Graphics2D g, Vector v, Vector w){
        g.draw(new Line2D.Double(jc(v, R, Org)[0],jc(v, R, Org)[1],jc(w, R, Org)[0],jc(w, R, Org)[1]));
    }
    
    //Draws a line between two points in vector coordinates in color C
    public void drawLine(Graphics2D g, Vector v, Vector w, Color C){
        g.setColor(C);
        g.draw(new Line2D.Double(jc(v, R, Org)[0],jc(v, R, Org)[1],jc(w, R, Org)[0],jc(w, R, Org)[1]));
    }
    
    /////////////////////////////////////
    /////  LINES FOR NEW CLASSES    ////
    /////////////////////////////////////
    
    //Draw line from two RVecs in vector coordinates
    public void drawLine(Graphics2D g, RVector v, RVector w){
        drawLine(g, v.vapp, w.vapp);
    }
    
    //Draw line from two RVecs in vector coordinates in Color C
    public void drawLine(Graphics2D g, RVector v, RVector w, Color C){
        g.setColor(C);
        drawLine(g, v.vapp, w.vapp);
    }
    
    //Draw line from two Particles in vector coordinates
    public void drawLine(Graphics2D g, Particle p1, Particle p2){
        drawLine(g, p1.coords, p2.coords);
    }
    
    //Draw line from two Particles in vector coordinates in Color C
    public void drawLine(Graphics2D g, Particle p1, Particle p2, Color C){
        g.setColor(C);
        drawLine(g, p1.coords, p2.coords);
    }
    
    
    
    
    ////////////////////
    /////  RAYS    ////
    ////////////////////
    
    //Draws a ray at point p pointed in vector v
    public void drawRay(Graphics2D g, Vector p, Vector v){
        g.draw(new Line2D.Double(jc(p, R, Org)[0],jc(p, R, Org)[1],jc(p.plus(p,v), R, Org)[0],jc(p.plus(p,v), R, Org)[1]));
    }
    
    //Draws a ray a point p pointed in vector v in color C
    public void drawRay(Graphics2D g, Vector p, Vector v, Color C){
        g.setColor(C);
        g.draw(new Line2D.Double(jc(p, R, Org)[0],jc(p, R, Org)[1],jc(p.plus(p,v), R, Org)[0],jc(p.plus(p,v), R, Org)[1]));
    }
    
     //////////////////////////////////
    /////  RAYS FOR NEW CLASSES    ////
    //////////////////////////////////
    
    //Draw a ray from RVec directed in v RVec
    public void drawRay(Graphics2D g, RVector p, RVector w){
        drawRay(g, p.vapp, w.vapp);
    }
    
    //Draws a ray a point p pointed in Rvector v in color C
    public void drawRay(Graphics2D g, RVector p, RVector v, Color C){
        g.setColor(C);
        drawRay(g, p.vapp, v.vapp, C);
    }
    
    //Draws a ray a Particle p pointed in Rvector v in color C
    public void drawRay(Graphics2D g, Particle p1, RVector v, Color C){
        g.setColor(C);
        drawRay(g, (p1.coords), v, C);
    }
    
    //Draws a ray a Particle p pointed in Rvector v 
    public void drawRay(Graphics2D g, Particle p1, RVector v){
        drawRay(g, p1.coords, v);
    }
    
    
    /////////////////////
    /////  SHAPES    ////
    /////////////////////
    
    //Draw a point in vector coordinates
    public void drawPoint(Graphics2D g, Vector v){
        drawLine(g, v, v);
    }
    
    //Draws a circle with coordinates x,y and radius r (java does diameter)
    public void drawCircle(Graphics2D g, Vector v, Double rad){
        g.draw(new Ellipse2D.Double(jc(v, R, Org)[0] - ((rad)/R)*(screensize/2) , jc(v, R, Org)[1] - ((rad)/R)*(screensize/2), (rad/R)*(screensize), (rad/R)*(screensize)));
    }
    
   //Draws a circle at RVector rv, with radius r
    public void drawCircle(Graphics2D g, RVector rv, Double rad){
        drawCircle(g, rv.vapp, rad);
    }
    
    //Draws a circle at RVector rv, with radius r with color C
    public void drawCircle(Graphics2D g, RVector rv, Double rad, Color C){
        g.setColor(C);
        drawCircle(g, rv.vapp, rad);
    }
    
    //Draws a circle at Particle p, with radius r with color C
    public void drawCircle(Graphics2D g, Particle p, Double rad, Color C){
        g.setColor(C);
        drawCircle(g, p.coords, rad);
    } 
    
    //Paint
    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                             RenderingHints.VALUE_ANTIALIAS_ON);
        
        ////////////////////////////////////////
        ///// ACTUALLY PAINTING THINGS    //////
        ////////////////////////////////////////
        
        //Sets size of grid and shift
        int gridsize = 100;
        int shift = 0;
        
        //Test particle for accessing methods
        Particle testP = new Particle(k1, k2);
        //Gets the vertices
        RVector[][] quadsofvertices = new RVector[2*gridsize+1][2*gridsize+1]; 
        Arrays.setAll(quadsofvertices,
            i -> {
                    RVector[] temp = new RVector[2*gridsize+1];
                        Arrays.setAll(temp,j -> testP.dev(k1,k2,(-1-gridsize+shift)+i,(-1-gridsize+shift)+j)
                                 );
                    return temp;
                });
                  
        //Draws a 3x3 grid if onlyone is false
        if(onlyone == false){
        
            //Draws the lines connecting vertices
            for(int i= 0; i < 2*gridsize; i++){
                for(int j=0; j < 2*gridsize; j++){
                    drawLine(g2, quadsofvertices[i][j], quadsofvertices[i][j+1], Color.RED);
                    drawLine(g2, quadsofvertices[i][j], quadsofvertices[i+1][j], Color.BLUE);
                    drawCircle(g2, quadsofvertices[i][j], 0.03, Color.BLACK);
                }
            }
            for(int j=0; j < 2*gridsize; j++){
                drawLine(g2, quadsofvertices[2*gridsize][j], quadsofvertices[2*gridsize][j+1], Color.RED);
                drawCircle(g2, quadsofvertices[2*gridsize][j], 0.03, Color.BLACK);
                drawLine(g2, quadsofvertices[j][2*gridsize], quadsofvertices[j+1][2*gridsize], Color.BLUE);
                drawCircle(g2, quadsofvertices[j][2*gridsize], 0.03, Color.BLACK);
            }
            drawCircle(g2, quadsofvertices[gridsize][2*gridsize], 0.03, Color.BLACK);
        }
        
        //Draws a 1x1 grid otherwise
        else{
            //4
            drawLine(g2, quadsofvertices[1+gridsize][1+gridsize], quadsofvertices[1+gridsize][2+gridsize], Color.BLACK);
            drawCircle(g2, quadsofvertices[1+gridsize][1+gridsize], 0.03, Color.BLACK);
            //3
            drawLine(g2, quadsofvertices[1+gridsize][2+gridsize], quadsofvertices[2+gridsize][2+gridsize], Color.BLUE);
            drawCircle(g2, quadsofvertices[1+gridsize][2+gridsize], 0.03, Color.BLUE);
            //2
            drawLine(g2, quadsofvertices[2+gridsize][2+gridsize], quadsofvertices[2+gridsize][1+gridsize], Color.GREEN);
            drawCircle(g2, quadsofvertices[2+gridsize][2+gridsize], 0.03, Color.GREEN);
            //1
            drawLine(g2, quadsofvertices[2+gridsize][1+gridsize], quadsofvertices[1+gridsize][1+gridsize], Color.RED);
            drawCircle(g2, quadsofvertices[2+gridsize][1+gridsize], 0.03, Color.RED);
        }
        
       
    
    }
    
    
    //Mouse commands
    public void mouseClicked(MouseEvent e){
        //Tells you where you click
        Vector v = vc(e.getX(), e.getY(), R, Org);
        Vector w = new Vector(new double[] {v.data[0], v.data[1]});
        w.print();
    }
        
    public void mousePressed(MouseEvent e){}
    public void mouseEntered(MouseEvent e){}
    public void mouseExited(MouseEvent e){}
    public void mouseReleased(MouseEvent e){}
    
}