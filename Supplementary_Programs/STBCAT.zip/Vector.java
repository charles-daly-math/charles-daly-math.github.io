public class Vector{
    public double[] data;
    public int size;
    
    ////////////////////////////////
    ////// CONSTRUCTING VECTORS  ///
    ////////////////////////////////
    
    //Makes a nx1 zero vector;
    public Vector(int n){
        this.data = new double[n];
        this.size = n;
        for(int i =0; i < n; i++){
            this.data[i] = 0.0;
        }
    }
    
    //Makes a nx1 vector from data;
    public Vector(double[] list){
        this.size = list.length;
        this.data = new double[list.length];
        for(int i =0; i < list.length; i++){
            this.data[i] = list[i];
        }
    }
    
    
    ///////////////////////////////
    ////// ALGEBRA OF VECTORS  ///
    ///////////////////////////////
    
    //Multiplies a vector by a constant
    public static Vector scale(double s, Vector v){
        Vector u = new Vector(v.size);
        for(int i =0; i < v.size; i++){
            u.data[i] = s*v.data[i];
        }
        return u;
    }
    
    //Adds two vector together
    public static Vector plus(Vector v, Vector w){
        //Checks if same size
        if (v.size != w.size){
            throw new IllegalArgumentException("Matrix and vector not the same size");
        }
        
        Vector u = new Vector(v.size);
        for(int i =0; i<v.size; i++){
            u.data[i] = v.data[i] + w.data[i];
        }
        
        return u;
    }
    
    //Subtracts two vectors
    public static Vector minus(Vector v, Vector w){
        //Checks if same size
        if (v.size != w.size){
            throw new IllegalArgumentException("Matrix and vector not the same size");
        }
        
        return plus(v,scale(-1.0,w));
    }
    
    //Returns a linear combination of vectors {v1,v2,...,vn} with weights {c1,c2,...,cn}
    public static Vector lincomb(double[] scalars, Vector[] vlist){
        //Checks if same size
        if (scalars.length != vlist.length){
            throw new IllegalArgumentException("Matrix and vector not the same size");
        }
        
        //Should probably check each vector same size...
        Vector w = new Vector(vlist[0].size);
        for(int i = 0; i < scalars.length; i++){
            w = plus(w,scale(scalars[i],vlist[i]));
        }
        
        return w;
    }
    
    //Multiplies a matrix and a vector 
    public static Vector mult(Matrix A, Vector v){
        //Checks if same size
        if (A.size != v.size){
            throw new IllegalArgumentException("Matrix and vector not the same size");
        }
        
        //Multiplies entries adds up
        Vector w = new Vector(A.size);
        w.size = A.size;
        for(int i = 0; i < A.size; i++){
            for(int j = 0; j < A.size; j++){
                w.data[i] = w.data[i]+A.data[i][j]*v.data[j];
            }
        }
        
        return w;
    }
    
    //Returns dot product
    public static double dot(Vector v, Vector w){
        //Checks if right size
        if (w.size != v.size){
            throw new IllegalArgumentException("Vectors must be same size");
        }
        double d = 0;
        for(int i =0; i < v.size; i++){
            d = d + v.data[i]*w.data[i];
        }
        return d;
    }
    
    //Returns norm of a vector
    public static double norm(Vector v){
        return Math.sqrt(dot(v,v));
    }
    
    //Returns division of vectors in the obvious sense
    public static Vector divide(Vector v, Vector w){
        //Checks if same size
        if (v.size != w.size){
            throw new IllegalArgumentException("Matrix and vector not the same size");
        }
        //Should add a check if w has zero, but here we are
        Vector u = new Vector(v.size);
        for(int i =0; i<v.size; i++){
            u.data[i] = (v.data[i])/(w.data[i]);
        }
        
        return u;
    }
    
    //Returns unit direction of a vector
    public static Vector unitvec(Vector v){
        return scale(1.0/norm(v), v);
    }
    
    ///////////////////////////////
    ////// VECTOR MANIPULATION  ////
    ///////////////////////////////
    
    //Appends to a vector to another vector
    public static Vector app(Vector v, Vector w){
        Vector u = new Vector(v.size+w.size);
        u.size = v.size + w.size;
        
        for(int i=0; i < v.size; i++){
            u.data[i] = v.data[i];
        }
        
        for(int i =v.size; i < u.size; i++){
            u.data[i] = w.data[i-v.size];
        }
        
        return u;
    }
    
    //Appends a single double to a vector
    public static Vector app(Vector v, double d){
        return v.app(v, new Vector(new double[] {d}));
    }
    
    //Prints a vector
    public void print(){
        System.out.println("Your vector has coordinates");
        String str = "{";
        for(int i =0; i < size; i++){
            if((i != size-1) && (i != 0)){
                str = str+" , "+data[i];
            }
            else if(i == 0){
                str = str+data[i];
            }
            else{
                str = str+" , "+data[i]+"}";
            }
        }
        System.out.println(str);
    }
    
    
    
}