public class Particle{
    //Parameters (k1,k2) for point, a pair of integers for the anchor polygon, a boolean to indicate horizontal or vertical, and a double s to indicate how to develop along on either direction, and a vector indicating initial direction
    public Rational k1;
    public Rational k2;
    
    //Anchor and type
    public int na;
    public int ma;
    public int type;
    
    //Rational parameter and corresponding coordinates
    public Rational spar;
    public RVector coords;
    
    //Vectors representing tangents of side1, side2, ..., side4 in counter-clockwise order, and the direction dir of inward.  
    public RVector tang1;
    public RVector tang2;
    public RVector tang3;
    public RVector tang4;
    public RVector dir;
    
    //Points representing vertices of side1, side2, side3, side 4 in counter-clockwise order
    public RVector y0;
    public RVector y1;
    public RVector y2;
    public RVector y3;
    
    //Integer vector to keep track of what's right/forward/left
    public int[] rfltypes;
    
    //Vectors for shifting anchord right/forward/left
    public int[] rshift;
    public int[] fshift;
    public int[] lshift;
    
    //Diagonal vectors
    public RVector diag1;
    public RVector diag2;
    
    
    
    
    ////////////////////////////////////////
    /////// CONSTRUCTIN PARTICLES  ////////
    ////////////////////////////////////////
    
    
    //Makes a particle via parameter s anchored at (na,ma) horizontally or vertically.  For example if tangent (1-s)dev(na,ma) + sdev(na+1,ma) horizontally and (1-s)dev(na,ma)+sdev(na,ma+1);
    public Particle(Rational pk1, Rational pk2, int pna, int pma, int ptype, Rational ps, RVector pdir){
        //Rational parameters
        this.k1 = pk1;
        this.k2 = pk2;
        
        //Checks to make sure tile is convex
        Boolean concheck = Rational.convexcheck(k1,k2);
        if(concheck == false){
                throw new NumberFormatException("Your ("+(pk1.strsymb)+" , "+(pk2.strsymb)+") "+"tile is not positively oriented convex at ("+pna+" , "+pma+")");
            }
        
        //Anchor and type
        this.na = pna;
        this.ma = pma;
        this.type = ptype;
        
        //Parameter and direction
        this.spar = ps;
        this.dir = pdir;
        
        //Calculates the vertices
        RVector c0 = dev(k1, k2, na, ma);
        RVector c1 = dev(k1, k2, na + 1, ma);
        RVector c2 = dev(k1, k2, na + 1, ma + 1);
        RVector c3 = dev(k1, k2, na, ma + 1);
        
        //Calculates various tangents
        RVector tan1 = RVector.sub(c1, c0);
        RVector tan2 = RVector.sub(c2, c1);
        RVector tan3 = RVector.sub(c3, c2);
        RVector tan4 = RVector.sub(c0, c3);
        
        //////////////////////////////////
        /////// SIDE 1 CONSTRUCTION /////
        //////////////////////////////////
        
        if(type == 1){
            //Coordinates for the particle and supporting tangent line where {tang, dir} are _positively_ oriented, along with other tangents cyclically ordered.
            this.coords = RVector.affcomb(spar, c0, c1);
            this.tang1 = tan1;
            this.tang2 = tan2;
            this.tang3 = tan3;
            this.tang4 = tan4;
            
            //Checks to make sure positively oriented and parameter is good
            RMatrix check = new RMatrix(tang1, dir);
            Rational checkdet = RMatrix.det(check);
            Boolean pcheck = Rational.incbet01(spar);
            if(checkdet.pos(checkdet) == false){
                throw new NumberFormatException("Your ("+(pk1.strsymb)+" , "+(pk2.strsymb)+") "+"tile is not positively oriented convex at ("+pna+" , "+pma+")");
            }
            if(pcheck == false){
                spar.print();
                throw new NumberFormatException("Your ("+(pk1.strsymb)+" , "+(pk2.strsymb)+") "+" parameter is strictly between 0 and 1 at ("+pna+" , "+pma+")");
            }
            
            //Coordinates for the vertices cyclically ordered.
            this.y0 = c0;
            this.y1 = c1;
            this.y2 = c2;
            this.y3 = c3;
            
            //Lets you know which sides are to the right/forward/left once moved to rfl
            this.rfltypes = new int[] {0,1,2};
            
            //Tells you how much to change anchor by depending on shift type
            this.rshift = new int[] {1,0};
            this.fshift = new int[] {0,1};
            this.lshift = new int[] {-1,0};
            
            
            //Diagonal vectors
            this.diag1 = RVector.sub(c2, coords);
            this.diag2 = RVector.sub(c3, coords);
        }
        
        //////////////////////////////////
        /////// SIDE 2 CONSTRUCTION /////
        //////////////////////////////////
        
        else if(type == 2){
            //Coordinates for the particle and supporting tangent line where {tang, dir} are _positively_ oriented
            this.coords = RVector.affcomb(spar, c1, c2);
            this.tang1 = tan2;
            this.tang2 = tan3;
            this.tang3 = tan4;
            this.tang4 = tan1;
            
            //Checks to make sure positively oriented and parameter is good
            RMatrix check = new RMatrix(tang1, dir);
            Rational checkdet = RMatrix.det(check);
            Boolean pcheck = Rational.incbet01(spar);
            if(checkdet.pos(checkdet) == false){
                throw new NumberFormatException("Your ("+(pk1.strsymb)+" , "+(pk2.strsymb)+") "+"tile is not positively oriented convex at ("+pna+" , "+pma+")");
            }
            if(pcheck == false){
                spar.print();
                throw new NumberFormatException("Your ("+(pk1.strsymb)+" , "+(pk2.strsymb)+") "+" parameter is strictly between 0 and 1 at ("+pna+" , "+pma+")");
            }
            
            //Coordinates for the vertices cyclically ordered.
            this.y0 = c1;
            this.y1 = c2;
            this.y2 = c3;
            this.y3 = c0;
            
            //Lets you know which sides are to the right/forward/left once moved to rfl
            this.rfltypes = new int[] {1,2,3};
            
            //Tells you how much to change anchor by depending on shift type
            this.rshift = new int[] {0,1};
            this.fshift = new int[] {-1,0};
            this.lshift = new int[] {0,-1};
            
            //Diagonal vectors
            this.diag1 = RVector.sub(c3, coords);
            this.diag2 = RVector.sub(c0, coords);
        }
        
        //////////////////////////////////
        /////// SIDE 3 CONSTRUCTION /////
        //////////////////////////////////
        
        else if(type == 3){
            //Coordinates for the particle and supporting tangent line where {tang, dir} are _positively_ oriented
            this.coords = RVector.affcomb(spar, c2, c3);
            this.tang1 = tan3;
            this.tang2 = tan4;
            this.tang3 = tan1;
            this.tang4 = tan2;
            
            //Checks to make sure positively oriented and parameter is good
            RMatrix check = new RMatrix(tang1, dir);
            Rational checkdet = RMatrix.det(check);
            Boolean pcheck = Rational.incbet01(spar);
            if(checkdet.pos(checkdet) == false){
                throw new NumberFormatException("Your ("+(pk1.strsymb)+" , "+(pk2.strsymb)+") "+"tile is not positively oriented convex at ("+pna+" , "+pma+")");
            }
            if(pcheck == false){
                spar.print();
                throw new NumberFormatException("Your ("+(pk1.strsymb)+" , "+(pk2.strsymb)+") "+" parameter is strictly between 0 and 1 at ("+pna+" , "+pma+")");
            }
            
            //Coordinates for the vertices cyclically ordered.
            this.y0 = c2;
            this.y1 = c3;
            this.y2 = c0;
            this.y3 = c1;
            
            //Lets you know which sides are to the right/forward/left once moved to rfl
            this.rfltypes = new int[] {2,3,0};
            
            //Tells you how much to change anchor by depending on shift type
            this.rshift = new int[] {-1,0};
            this.fshift = new int[] {0,-1};
            this.lshift = new int[] {1,0};
            
            //Diagonal vectors
            this.diag1 = RVector.sub(c0, coords);
            this.diag2 = RVector.sub(c1, coords);
        }
        
        
        //////////////////////////////////
        /////// SIDE 4 CONSTRUCTION /////
        //////////////////////////////////

        else {
            //Coordinates for the particle and supporting tangent line where {tang, dir} are _positively_ oriented
            this.coords = RVector.affcomb(spar, c3, c0);
            this.tang1 = tan4;
            this.tang2 = tan1;
            this.tang3 = tan2;
            this.tang4 = tan3;
            
            //Checks to make sure positively oriented and parameter is good
            RMatrix check = new RMatrix(tang1, dir);
            Rational checkdet = RMatrix.det(check);
            Boolean pcheck = Rational.incbet01(spar);
            if(checkdet.pos(checkdet) == false){
                throw new NumberFormatException("Your ("+(pk1.strsymb)+" , "+(pk2.strsymb)+") "+"tile is not positively oriented convex at ("+pna+" , "+pma+")");
            }
            if(pcheck == false){
                spar.print();
                throw new NumberFormatException("Your ("+(pk1.strsymb)+" , "+(pk2.strsymb)+")"+" parameter is strictly between 0 and 1 at ("+pna+" , "+pma+")");
            }
            
            //Coordinates for the vertices cyclically ordered.
            this.y0 = c3;
            this.y1 = c0;
            this.y2 = c1;
            this.y3 = c2;
            
            //Lets you know which sides are to the right/forward/left once moved to rfl
            this.rfltypes = new int[] {3,0,1};
            
            //Tells you how much to change anchor by depending on shift type
            this.rshift = new int[] {0,-1};
            this.fshift = new int[] {1,0};
            this.lshift = new int[] {0,1};
            
            //Diagonal vectors
            this.diag1 = RVector.sub(c1, coords);
            this.diag2 = RVector.sub(c2, coords);
        }
    }
    
    //Makes a particle at the vertex (na,ma), direction and parameter trivial.
    public Particle(Rational pk1, Rational pk2, int pna, int pma){
        this.k1 = pk1;
        this.k2 = pk2;
        this.na = pna;
        this.ma = pma;
        
        this.spar = new Rational();
        this.dir = new RVector();
        
        this.coords = dev(k1, k2, na,ma);
    }
    
    //Makes a blank particle just to access methods, direction and parameter trivial.  Probably just going to use to draw the grid and do calculations.
    public Particle(Rational pk1, Rational pk2){
        this.na = 0;
        this.ma = 0;
        
        this.k1 = pk1;
        this.k2 = pk2;
        
        this.spar = new Rational();
        this.dir = new RVector();
        
        this.coords = dev(k1, k2, na,ma);
    }
    
    

    //////////////////////////////////
    /////// DEVELOPING MAP STUFF  ////
    /////////////////////////////////
    
    //////////////////////////////////////////////////////
    //////    Note this program only needs vertices //////
    //////////////////////////////////////////////////////
    
    //Developing map for (k1, k2) torus
    public static RVector dev(Rational pk1, Rational pk2, int na, int ma){
        RVector anchor = new RVector(na, ma);
        Rational rat = RVector.dot(new RVector(pk1, pk2), anchor);
        rat = rat.mult(new Rational(1,2), rat.power(rat,2));
        return RVector.add(
            new RVector[] {anchor, anchor.scale(rat, new RVector(pk2, Rational.neg(pk1)))}
        );
    }  
    

    
    //////////////////////////////////
    /////// INSTERSECTION STUFF  ////
    /////////////////////////////////
    
    //Here's our labeling of a quadraliteral//
    //////////////////////////////////////////
    ///                                     //
    ///                  3                  //
    ///        c3///////////////c2          //
    ///        //              //           //
    ///        //              //           //
    ///    4   //              //      2    //
    ///        //              //           //
    ///        //              //           //
    ///        c0///////////////c1          //
    ///                 1                   //
    ///                                     //
    //////////////////////////////////////////
    
    //Here's some diagonals for side 1 
    //////////////////////////////////////////
    ///                                     //
    ///                  3                  //
    ///        c3///////////////c2          //
    ///        //\            / //          //
    ///        // \         /   //          //
    ///    4   //  \      /     //      2   //
    ///        //   \   /   hd1 //          //
    ///        // hd2 \ /       //          //
    ///        c0////p//////////c1          //
    ///                 1                   //
    ///                                     //
    //////////////////////////////////////////
    
    ///Here's some diagonals for side 4     
    ////////////////////////////////////////
    ///                                   //
    ///                  3                //
    ///        c3/////////////c2          //
    ///        //      ////   //          //
    ///        //  //// vd2   //          //
    ///    4   p --           //      2   //
    ///        //  \\\   vd1  //          //
    ///        //      \\\    //          //
    ///        c0////////////c1           //
    ///                 1                 //
    ///                                   //
    ////////////////////////////////////////
    
    
    
    
    
    
    
    /////////////////////////////////////////////////////////////
    ///// INTERIOR DIRECTION FOR SIDE 1 AT ANCHOR (na, ma) /////
    ////////////////////////////////////////////////////////////
    
    public static RVector inside1(Rational pk1, Rational pk2, int pna, int pma){
        //Declaring temporary variables
        Rational tk1 = pk1;
        Rational tk2 = pk2;
        int tna = pna;
        int tma = pma;
        
        //Constructing lists for multiplication / addition / substraction
        
        // negative k1(k2^2)ma
        Rational[] list1 = new Rational[] {new Rational(-1),tk1, tk2, tk2, new Rational(tma)};
        Rational t1 = Rational.mult(list1);
        
        // negative (k1^2)k2na
        Rational[] list2 = new Rational[] {new Rational(-1), tk1, tk1, tk2, new Rational(tna)};
        Rational t2 = Rational.mult(list2);
        
        // (k1^2)k2ma
        Rational[] list3 = new Rational[] {tk1, tk1, tk2, new Rational(tma)};
        Rational t3 = Rational.mult(list3);
        
        // (k1^3)na
        Rational[] list4 = new Rational[] {tk1, tk1, tk1, new Rational(tna)};
        Rational t4 = Rational.mult(list4);
        
        // (k2^3)ma
        Rational[] list5 = new Rational[] {tk2, tk2, tk2, new Rational(tma)};
        Rational t5 = Rational.mult(list5);
        
        // (k2^2)k1na
        Rational[] list6 = new Rational[] {tk2, tk2, tk1, new Rational(tna)};
        Rational t6 = Rational.mult(list6);
        
        
        //Components of vectors
        Rational v1x = Rational.add(new Rational[] {new Rational(-1), t1, t2});
        Rational v1y = Rational.add(new Rational[] {t3, t4});
        
        Rational v2x = Rational.add(new Rational[] {t5, t6});
        Rational v2y = Rational.add(new Rational[] {new Rational(1), t1, t2});
        
        //Constructing the actual vectors to return
        RVector rv1 = new RVector(v1x,v1y);
        RVector rv2 = new RVector(v2x,v2y);
        
        //Returning depending on signs of k1
        if(Rational.isneg(tk1) == true){
            return rv1;
        }
        else if(Rational.pos(tk1) == true){
            return RVector.neg(rv1);
        }
        else{
            return rv2;
        }
    }
    
    
    
    /////////////////////////////////////////////////////////////
    ///// INTERIOR DIRECTION FOR SIDE 2 AT ANCHOR (na, ma) /////
    ////////////////////////////////////////////////////////////
    
    public static RVector inside2(Rational pk1, Rational pk2, int pna, int pma){
        //Declaring temporary variables
        Rational tk1 = pk1;
        Rational tk2 = pk2;
        int tna = pna;
        int tma = pma;
        
        //Constructing lists for multiplication / addition / substraction
        
        // negative k1(k2^2)
        Rational[] list1 = new Rational[] {new Rational(-1), tk1, tk2, tk2};
        Rational t1 = Rational.mult(list1);
        
        // negative (k2^3)ma
        Rational[] list2 = new Rational[] {new Rational(-1), tk2, tk2, tk2, new Rational(tma)};
        Rational t2 = Rational.mult(list2);
        
        // negative k1(k2^2)na
        Rational[] list3 = new Rational[] {new Rational(-1), tk1, tk2, tk2, new Rational(tna)};
        Rational t3 = Rational.mult(list3);
        
        // (k1^2)k2
        Rational[] list4 = new Rational[] {tk1, tk1, tk2};
        Rational t4 = Rational.mult(list4);
        
        // k1(k2^2)ma
        Rational[] list5 = new Rational[] {tk1, tk2, tk2, new Rational(tma)};
        Rational t5 = Rational.mult(list5);
        
        // (k1^2)k2na
        Rational[] list6 = new Rational[] {tk1, tk1, tk2, new Rational(tna)};
        Rational t6 = Rational.mult(list6);
        
        // (k1^3)
        Rational[] list7 = new Rational[] {tk1, tk1, tk1};
        Rational t7 = Rational.mult(list7);
        
        // (k1^2)k2ma
        Rational[] list8 = new Rational[] {tk1, tk1, tk2, new Rational(tma)};
        Rational t8 = Rational.mult(list8);
        
        // (k1^3)na
        Rational[] list9 = new Rational[] {tk1, tk1, tk1, new Rational(tna)};
        Rational t9 = Rational.mult(list9);
        
        
        //Components of vectors
        Rational v1x = Rational.add(new Rational[] {t1, t2, t3});
        Rational v1y = Rational.add(new Rational[] {new Rational(-1), t4, t5, t6});
        
        Rational v2x = Rational.add(new Rational[] {new Rational(-1), Rational.neg(t4), Rational.neg(t5), Rational.neg(t6)});
        Rational v2y = Rational.add(new Rational[] {t7, t8, t9});
        
        //Constructing the actual vectors to return
        RVector rv1 = new RVector(v1x, v1y);
        RVector rv2 = new RVector(v2x, v2y);
        
        //Returning depending on signs of k2
        if(Rational.isneg(tk2) == true){
            return rv1;
        }
        else if(Rational.pos(tk2) == true){
            return RVector.neg(rv1);
        }
        else{
            return rv2;
        }
    }
    
    
    /////////////////////////////////////////////////////////////
    ///// INTERIOR DIRECTION FOR SIDE 3 AT ANCHOR (na, ma) /////
    ////////////////////////////////////////////////////////////
    
    public static RVector inside3(Rational pk1, Rational pk2, int pna, int pma){
        //Declaring temporary variables
        Rational tk1 = pk1;
        Rational tk2 = pk2;
        int tna = pna;
        int tma = pma;
        
        //Constructing lists for multiplication / addition / substraction
        
        // k1(k2^2)
        Rational[] list1 = new Rational[] {tk1, tk2, tk2};
        Rational t1 = Rational.mult(list1);
        
        // k1(k2^2)ma
        Rational[] list2 = new Rational[] {tk1, tk2, tk2, new Rational(tma)};
        Rational t2 = Rational.mult(list2);
        
        // (k1^2)k2na
        Rational[] list3 = new Rational[] {tk1, tk1, tk2, new Rational(tna)};
        Rational t3 = Rational.mult(list3);
        
        // negative (k1^2)k2
        Rational[] list4 = new Rational[] {new Rational(-1), tk1, tk1, tk2};
        Rational t4 = Rational.mult(list4);
        
        // negative (k1^2)k2ma
        Rational[] list5 = new Rational[] {new Rational(-1), tk1, tk1, tk2, new Rational(tma)};
        Rational t5 = Rational.mult(list5);
        
        // negative (k1^3)na
        Rational[] list6 = new Rational[] {new Rational(-1), tk1, tk1, tk1, new Rational(tna)};
        Rational t6 = Rational.mult(list6);
        
        // negative (k2^3)
        Rational[] list7 = new Rational[] {new Rational(-1), tk2, tk2, tk2};
        Rational t7 = Rational.mult(list7);
        
        // negative (k2^3)ma
        Rational[] list8 = new Rational[] {new Rational(-1), tk2, tk2, tk2, new Rational(tma)};
        Rational t8 = Rational.mult(list8);
        
        // negative k1(k2^2)na
        Rational[] list9 = new Rational[] {new Rational(-1), tk1, tk2, tk2, new Rational(tna)};
        Rational t9 = Rational.mult(list9);
        
        
        //Components of vectors
        Rational v1x = Rational.add(new Rational[] {new Rational(1), t1, t2, t3});
        Rational v1y = Rational.add(new Rational[] {t4, t5, t6});
        
        Rational v2x = Rational.add(new Rational[] {t7, t8, t9});
        Rational v2y = Rational.add(new Rational[] {new Rational(-1), t1, t2, t3});
        
        //Constructing the actual vectors to return
        RVector rv1 = new RVector(v1x, v1y);
        RVector rv2 = new RVector(v2x, v2y);
        
        //Returning depending on signs of k2
        if(Rational.isneg(tk1) == true){
            return rv1;
        }
        else if(Rational.pos(tk1) == true){
            return RVector.neg(rv1);
        }
        else{
            return rv2;
        }
    }
    
    
    
    /////////////////////////////////////////////////////////////
    ///// INTERIOR DIRECTION FOR SIDE 4 AT ANCHOR (na, ma) /////
    ////////////////////////////////////////////////////////////
    
    public static RVector inside4(Rational pk1, Rational pk2, int pna, int pma){
        //Declaring temporary variables
        Rational tk1 = pk1;
        Rational tk2 = pk2;
        int tna = pna;
        int tma = pma;
        
        //Constructing lists for multiplication / addition / substraction
        
        // (k2^3)ma
        Rational[] list1 = new Rational[] {tk2, tk2, tk2, new Rational(tma)};
        Rational t1 = Rational.mult(list1);
        
        // k1(k2^2)na
        Rational[] list2 = new Rational[] {tk1, tk2, tk2, new Rational(tna)};
        Rational t2 = Rational.mult(list2);
        
        // negative k1(k2^2)ma
        Rational[] list3 = new Rational[] {new Rational(-1), tk1, tk2, tk2, new Rational(tma)};
        Rational t3 = Rational.mult(list3);
        
        // negative (k1^2)k2na
        Rational[] list4 = new Rational[] {new Rational(-1), tk1, tk1, tk2, new Rational(tna)};
        Rational t4 = Rational.mult(list4);
        
        // negative (k1^2)k2ma
        Rational[] list5 = new Rational[] {new Rational(-1), tk1, tk1, tk2, new Rational(tma)};
        Rational t5 = Rational.mult(list5);
        
        // negative (k1^3)na
        Rational[] list6 = new Rational[] {new Rational(-1), tk1, tk1, tk1, new Rational(tna)};
        Rational t6 = Rational.mult(list6);
        
        
        //Components of vectors
        Rational v1x = Rational.add(new Rational[] {t1, t2});
        Rational v1y = Rational.add(new Rational[] {new Rational(1), t3, t4});
        
        Rational v2x = Rational.add(new Rational[] {new Rational(1), Rational.neg(t3), Rational.neg(t4)});
        Rational v2y = Rational.add(new Rational[] {t5, t6});
        
        //Constructing the actual vectors to return
        RVector rv1 = new RVector(v1x,v1y);
        RVector rv2 = new RVector(v2x,v2y);
        
        //Returning depending on signs of k1
        if(Rational.isneg(tk2) == true){
            return rv1;
        }
        else if(Rational.pos(tk2) == true){
            return RVector.neg(rv1);
        }
        else{
            return rv2;
        }
    }
    
    
    ///////////////////////////////////////////////////////////////////////
    ////  GIVES INITIAL DIRECTION DEPENDING ON SIDES AND PARAMETERS  /////
    //////////////////////////////////////////////////////////////////////
    public static RVector ogdir(Rational pk1, Rational pk2, int pna, int pma, int pside){
        if(pside == 1){
            return inside1(pk1, pk2, pna, pma);
        }
        else if(pside == 2){
            return inside2(pk1, pk2, pna, pma);
        }
        else if(pside == 3){
            return inside3(pk1, pk2, pna, pma);
        }
        else{
            return inside4(pk1, pk2, pna, pma);
        }
    }
    
    
    
    
    
    
    ////////////////////////////
    ///////  INTERSECTION //////
    ////////////////////////////
    
    public static Particle intersection(Particle pp, RVector ndir){
        //Some initial data from particle
        
        //Rational parameters
        Rational ok1 = pp.k1;
        Rational ok2 = pp.k2;
        
        //Anchor and type
        int ona = pp.na;
        int oma = pp.ma;
        int otype = pp.type;
        
        //Parameter, direction, and tangent where {tan,dir} form a oriented basis
        Rational ot = pp.spar;
        RVector od = pp.dir;
        
        //These vectors are tangent sides relative to particle in question
        RVector v1 = pp.tang1;
        RVector v2 = pp.tang2;
        RVector v3 = pp.tang3;
        RVector v4 = pp.tang4;
        
        
        //Checks if ndir parallel to v1, spits out error if so
        RMatrix rtest = new RMatrix(v1, ndir);
        Rational rtestdet = rtest.det(rtest);
        if(rtestdet.iszero(rtestdet) == true){
            System.out.println("Your ("+(ok1.strsymb)+" , "+(ok2.strsymb)+")"+" has a parallel edge and new direction at ("+ona+" , "+oma+")");
            throw new NumberFormatException("New direction is parallel to edge!");
        }
        
        //Orients the new direction correctly 
        ndir = RVector.orient(v1, od, ndir);
        
        
        //Right, forward, left relative to current particle and how to change anchors accordingly
        int[] rflints = pp.rfltypes;
        int[] rmove = pp.rshift;
        int[] fmove = pp.fshift;
        int[] lmove = pp.lshift;
        
        //Solves for ndir relative to {v1,v2} so ndir = x1v1 + x2v2;
        RVector xs = ndir.coefs(v1, v2, ndir);
        
        //Determines to move right/forward/left via the diagonals in question
        RVector d1 = pp.diag1;
        RVector d2 = pp.diag2;
        int ws = whichside(d1, d2, ndir);
        
        ////////////////////////////////////
        /////// RIGHT INTERSECTION /////////
        ///////////////////////////////////
        if(ws == 0){
            //Defines new parameter 
            Rational q1 = Rational.div(xs.z2,xs.z1);
            Rational q2 = Rational.mult(q1,ot);
            Rational q3 = Rational.sub(new Rational(1),q1);
            Rational q4 = Rational.add(q2,q3);
            
            //Checks if that new parameter is zero or one, if so, then you hit a vertex
            
            if(Rational.incbet01(q4) == false){
                throw new NumberFormatException("Your ("+(ok1.strsymb)+" , "+(ok2.strsymb)+")"+" anchor at ("+ona+" , "+oma+")"+"hit a vertex"); 
            }

            //Defines new anchor
            int nna = ona + rmove[0];
            int nma = oma + rmove[1];

            //Returns new particle
            return new Particle(ok1, ok2, nna, nma, rflints[0], q4, ndir);
        }
        
        ////////////////////////////////////
        /////// FORWARD INTERSECTION //////
        ///////////////////////////////////
        else if(ws == 1){
            //Solves for v3 relative to {v1,v2} so v3 = beta1v1 + beta2v2;
            RVector betas = v3.coefs(v1, v2, v3);

            //Makes a matrix whose columns are {xs,betas} then takes determinant
            RMatrix rM = new RMatrix(xs, betas);
            Rational detrM = rM.det(rM);

            //Defines new parameter 
            Rational q1 = Rational.div(xs.z2,detrM);
            Rational q2 = Rational.mult(q1,ot);
            Rational q3 = Rational.sub(xs.z1,xs.z2);
            Rational q4 = Rational.div(q3,detrM);
            Rational q5 = Rational.add(q2,q4);
            Rational q6 = Rational.add(new Rational(1),q5);
            
            
            //Checks if that new parameter is zero or one, if so, then you hit a vertex
            
            if(Rational.incbet01(q6) == false){
                throw new NumberFormatException("Your ("+(ok1.strsymb)+" , "+(ok2.strsymb)+")"+" anchor at ("+ona+" , "+oma+")"+"hit a vertex"); 
            }

            //Defines new anchor
            int nna = ona + fmove[0];
            int nma = oma + fmove[1];

            //Returns new particle
            return new Particle(ok1, ok2, nna, nma, rflints[1], q6, ndir);
        }
        
        ////////////////////////////////
        /////// LEFT INTERSECTION //////
        ////////////////////////////////
        else{
            //Solves for v4 relative to {v1,v2} so v4 = beta1v1 + beta2v2;
            RVector betas = v4.coefs(v1, v2, v4);

            //Makes a matrix whose columns are {xs,betas} then takes determinant
            RMatrix rM = new RMatrix(xs, betas);
            Rational detrM = rM.det(rM);

            //Defines new parameter 
            Rational q1 = Rational.div(xs.z2,detrM);
            Rational q2 = Rational.mult(q1,ot);
            
            //Checks if that new parameter is zero or one, if so, then you hit a vertex
            
            if(Rational.incbet01(q2) == false){
                throw new NumberFormatException("Your ("+(ok1.strsymb)+" , "+(ok2.strsymb)+")"+" anchor at ("+ona+" , "+oma+")"+"hit a vertex"); 
            }

            //Defines new anchor
            int nna = ona + lmove[0];
            int nma = oma + lmove[1];

            //Returns new particle
            return new Particle(ok1, ok2, nna, nma, rflints[2], q2, ndir);
        }
    }
    
    /////Takes two directions which are _positively oriented_, another third direction, side type, then spits out whether to take a right, forward, or left where r/f/l = 0/1/2
    public static int whichside(RVector v1, RVector v2, RVector w){
        //Positive v1 and v2 coefficient respectively
        Boolean[] posts = RVector.poscoords(v1, v2, w);
        Boolean hp1 = posts[0];
        Boolean hp2 = posts[1];
        //If in first hp but not second
        if((hp1 == true) && (hp2 == false)){
            return 0;
        }
        //If in both
        else if((hp1 == true) && (hp2 == true)){
            return 1;
        }
        //If w oriented correctly, then means it has to be the remaining.  Here we are assuming w is NOT in negative of both v1 and v2, which, if we first properly orient w will be true.  This is because v1, v2 form an oriented 
        else{
            return 2;
        }
    }
    
    
    
    //////////////////////////////////////
    ////////  ACTUAL ITERATION  /////////
    //////////////////////////////////////
    
    //Eats up a pair of particles (p,q) with parameters (k1,k2), (k3,k4) and spits out the iteration.
    public static Particle[] iterate(Particle[] ppair){
        Particle p = ppair[0];
        Particle q = ppair[1];
        
        //Takes the (unoriented) tangent of q.
        RVector newpdir = q.tang1;
        
        //Returns new particle from p and new direction of q.  Note newpdir gets oriented in the interseciton method.
        Particle np = intersection(p, newpdir);
        
        //Takes the (unoriented) tangent of np.
        RVector newqdir = np.tang1;
        
        //Returns new particle from q and new direction of p.  Note newqdir gets oriented in the interseciton method.
        Particle nq = intersection(q, newqdir);
        
        return new Particle[] {np, nq};
    }
    
    //////////////////////////////////////////
    ////////  CHANGES TIME PARAMETER  /////////
    //////////////////////////////////////////
    
    //This method takes a particle and pushes its rational parameter up by prat amount taking into account possible side changes and necessary direction changes.
    public static Particle pushup(Particle ppart, Rational prat){
        //Just gets the fractional part of prat which is the pushing amount
        Rational push = (Rational.divrem(prat))[1];
        //Calculates new parameter
        Rational tpar = Rational.add(ppart.spar, prat);
        //Writes it as integer shift + rational remainder
        Rational[] shiftpar = Rational.divrem(tpar);
        int sideshift = (shiftpar[0].num).intValue();
        //Finds the new side mod 4
        int nside = Math.floorMod(ppart.type + sideshift, 4);
        //New rational parameter
        Rational npar = shiftpar[1];
        //Ensures new rational parameter is not zero on the nose
        if((Rational.iszero(npar) == true) || (Rational.isone(npar) == true)){
            npar = Rational.add(npar, push);
        }
        //New direction
        RVector ndir = ogdir(ppart.k1, ppart.k2, ppart.na, ppart.ma, nside);
        return new Particle(ppart.k1, ppart.k2, ppart.na, ppart.ma, nside, npar, ndir);
    }
    
    //This method takes a particle and pulls its rational parameter up by prat amount taking into account possible side changes and necessary direction changes.
    public static Particle pullback(Particle ppart, Rational prat){
        //Just gets the fractional part of prat which is the pushing amount
        Rational pull = (Rational.divrem(prat))[1];
        //Calculates new parameter
        Rational tpar = Rational.sub(ppart.spar, prat);
        //Writes it as integer shift + rational remainder
        Rational[] shiftpar = Rational.divrem(tpar);
        int sideshift = (shiftpar[0].num).intValue();
        //Finds the new side mod 4
        int nside = Math.floorMod(ppart.type + sideshift, 4);
        //New rational parameter
        Rational npar = shiftpar[1];
        //Ensures new rational parameter is not zero on the nose
        if((Rational.iszero(npar) == true) || (Rational.isone(npar) == true)){
            //Need to subtract off a side 
            nside = Math.floorMod(nside-1, 4);
            npar = Rational.sub(new Rational(1), pull);
        }
        //New direction
        RVector ndir = ogdir(ppart.k1, ppart.k2, ppart.na, ppart.ma, nside);
        return new Particle(ppart.k1, ppart.k2, ppart.na, ppart.ma, nside, npar, ndir);
    }
    
    ///////////////////////////////////////////////////////
    /////////// CHECKS THAT PARAMETERS NON-DEGENERATE /////
    ///////////////////////////////////////////////////////
 
    ///This method ensures that the fundamental domain given by the vertices is convex and positively oriented as in Equation 3.9
    
//    public static Boolean convexcheck(Rational pk1, Rational pk2){
//        Rational tk1 = pk1;
//        Rational tk2 = pk2;
//        //k1*k2
//        Rational tk1k2 = Rational.mult(tk1,tk2);
//        //k1 + k2
//        Rational tsum = Rational.add(tk1,tk2);
//        //k1 - k2
//        Rational tdiff = Rational.sub(tk1,tk2);
//        
//        //2
//        Rational two = new Rational(2);
//        //k1k2*(k1+k2)
//        Rational term1 = Rational.mult(tk1k2,tsum);
//        //k1k2*(k1-k2)
//        Rational term2 = Rational.mult(tk1k2,tdiff);
//        
//        //2-k1k2*(k1+k2)
//        Rational sum1 = Rational.sub(two,term1);
//        //2-k1k2*(k1-k2)
//        Rational sum2 = Rational.sub(two,term2);
//        //2+k1k2*(k1+k2)
//        Rational sum3 = Rational.add(two,term1);
//        //2+k1k2*(k1-k2)
//        Rational sum4 = Rational.add(two,term2);
//
//        //Booleans to check
//        Boolean turn1 = Rational.pos(sum1);
//        Boolean turn2 = Rational.pos(sum2);
//        Boolean turn3 = Rational.pos(sum3);
//        Boolean turn4 = Rational.pos(sum4);
//        
//        Boolean turningsame = ((turn1) && (turn2) && (turn3) && (turn4));
//        
//        //If either signed products are positive, meaning no self intersection nor degenerated quadliterals becoming triangles, then returns true.
//        if(turningsame == true){
//            return true;
//        }
//        else{
//            return false;
//        }
//    }
    

    ////////////////////////////////////////
    /// PRINTS INFO ABOUT YOUR PARTICLE ///
    ///////////////////////////////////////
    
    public void print(){
        //Actual Coordinates 
        //String strc1 = (coords.z1).strsymb;
        //String strc2 = (coords.z2).strsymb;
        
        //Approximations of things
        Vector vapp1 = coords.vapp;
        Vector dirapp1 = dir.vapp;
        double k1app = k1.app;
        double k2app = k2.app;
        //Approximations of tang1,tang2,tang3,tang4
        Vector aptang1 = tang1.vapp;
        Vector udir1 = Vector.unitvec(aptang1);
        Vector aptang2 = tang2.vapp;
        Vector udir2 = Vector.unitvec(aptang2);
        Vector aptang3 = tang3.vapp;
        Vector udir3 = Vector.unitvec(aptang3);
        Vector aptang4 = tang4.vapp;
        Vector udir4 = Vector.unitvec(aptang4);
        //Printing stuff
        System.out.println("Your particle is anchored at: ("+na+" , "+ma+")");
        System.out.println("");
        System.out.println("Your particle has approximately (k1,k2) = ("+k1app+" , "+k2app+")");
        System.out.println("");
        System.out.println("It is located on side: "+type);
        System.out.println("");
//        System.out.println("Its affine parameter is: "+(spar.strsymb));
//        System.out.println("");
        System.out.println("Its affine parameter is about: "+(spar.app));
        System.out.println("");
//        System.out.println("Its coordinates are: ("+strc1+" , "+strc2+")");
        System.out.println("Its coordinates are about at ("+(vapp1.data[0])+" , "+(vapp1.data[1])+")");
        System.out.println("");
        System.out.println("The inside is in the direction approximately ("+(dirapp1.data[0])+" , "+(dirapp1.data[1])+")");
        System.out.println("");
        System.out.println("");
        System.out.println("Here are the approximate ordered UNIT vectors vi/|vi|,vi+1/|vi+1|,vi+2/|vi+2|,vi+3/|vi+3|");
        System.out.println("vi/|vi|: ("+udir1.data[0]+" , "+udir1.data[1]+")");
        System.out.println("vi+1/|vi+1|: ("+udir2.data[0]+" , "+udir2.data[1]+")");
        System.out.println("vi+2/|vi+2|: ("+udir3.data[0]+" , "+udir3.data[1]+")");
        System.out.println("vi+3/|vi+3|: ("+udir4.data[0]+" , "+udir4.data[1]+")");
        System.out.println("");
    }
    
}