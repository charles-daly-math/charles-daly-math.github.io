//Importing Array which for some reason doesn't work in main...?
import java.util.Arrays;

public class RMatrix{
    public Rational ra;
    public Rational rb;
    public Rational rc;
    public Rational rd;
    public Matrix mapp;
    
    ///////////////////////////////////////////////////
    /////   Some ways of constructing RMatrices  //////
    //////////////////////////////////////////////////
    
    //Makes a 2x2 zero matrix;
    public RMatrix(){
        this.ra = new Rational();
        this.rb = new Rational();
        this.rc = new Rational();
        this.rd = new Rational();
        this.mapp = new Matrix(new double[][] {
               {0.0, 0.0},
               {0.0, 0.0}
        });
    }
    
    //Makes a 2x2 rational matrix from four rationals;
    public RMatrix(Rational pra, Rational prb, Rational prc, Rational prd){
        this.ra = pra;
        this.rb = prb;
        this.rc = prc;
        this.rd = prd;
        this.mapp = new Matrix(new double[][] {
            {ra.app, rb.app},
            {rc.app, rd.app}
        });
    }
    
    //Makes a 2x2 rational matrix from four integers;
    public RMatrix(int pra, int prb, int prc, int prd){
        this.ra = new Rational(pra);
        this.rb = new Rational(prb);
        this.rc = new Rational(prc);
        this.rd = new Rational(prd);
        this.mapp = new Matrix(new double[][] {
            {ra.app, rb.app},
            {rc.app, rd.app}
        });
    }
    
    //Makes a 2x2 rational matrix from two rational vectors;
    public RMatrix(RVector v1, RVector v2){
        this.ra = v1.z1;
        this.rc = v1.z2;
        
        this.rb = v2.z1;
        this.rd = v2.z2;
        this.mapp = new Matrix(new double[][] {
            {ra.app, rb.app},
            {rc.app, rd.app}
        });
    }
    
    ///////////////////////////////////////////////
    /////   Does some stuff with RMatrices  //////
    /////////////////////////////////////////////
    
    
    //Matrix multiplication
    public static RMatrix mult(RMatrix m1, RMatrix m2){
        Rational m3a = RVector.dot(new RVector(m1.ra, m1.rb), new RVector(m2.ra, m2.rc));
        Rational m3b = RVector.dot(new RVector(m1.ra, m1.rb), new RVector(m2.rb, m2.rd));
        Rational m3c = RVector.dot(new RVector(m1.rb, m1.rd), new RVector(m2.ra, m2.rc));
        Rational m3d = RVector.dot(new RVector(m1.rb, m1.rd), new RVector(m2.rb, m2.rd));
        
        return new RMatrix(m3a, m3b, m3c, m3d); 
    }
    
    //Scales a matrix by a rational
    public static RMatrix scale(Rational r, RMatrix m1){
        return new RMatrix(
            r.mult(r,m1.ra),r.mult(r,m1.rb),
            r.mult(r,m1.rc),r.mult(r,m1.rd)
        );
    }
    
    //Inverts a matrix
    public static RMatrix inv(RMatrix m1){
        return scale(Rational.inv(det(m1)),
                    new RMatrix(
                        m1.rd, Rational.neg(m1.rb),
                        Rational.neg(m1.rc), m1.ra
                    )
                        );
    }
    
    //Adds two rational Matrices
    public static RMatrix add(RMatrix m1, RMatrix m2){
        return new RMatrix(
            Rational.add(m1.ra,m2.ra),
            Rational.add(m1.rb,m2.rb),
            Rational.add(m1.rc,m2.rc),
            Rational.add(m1.rd,m2.rd)
                );
    }
    
    //Multiplies a rational 2x2 matrix and a rational vector
    public static RVector linact(RMatrix m1, RVector v1){
        Rational w1 = RVector.dot(new RVector(m1.ra, m1.rb), new RVector(v1.z1, v1.z2));
        Rational w2 = RVector.dot(new RVector(m1.rc, m1.rd), new RVector(v1.z1, v1.z2));
        
        return new RVector(w1, w2);
    }
    
    //Multiplies a rational 2x2 matrix by a rational vector v1, and then translates by t1
    public static RVector affact(RMatrix m1, RVector t1, RVector v1){
        return RVector.add(linact(m1, v1), t1);
    }
    
    //Returns determinant of a 2x2 matrix.
    public static Rational det(RMatrix m1){
        return Rational.sub(
            Rational.mult(m1.ra,m1.rd),
            Rational.mult(m1.rb,m1.rc)
        );
    }

    //Prints a rational matrix
    public void print(){
        System.out.println("Your matrix has values: ");
        System.out.println("{"+(ra.num)+"/"+(ra.den)+" , "+(rb.num)+"/"+(rb.den)+"}");
        System.out.println("{"+(rc.num)+"/"+(rc.den)+" , "+(rd.num)+"/"+(rd.den)+"}");
        System.out.println("and is approximately");
        mapp.print();
    }
    
    
    
}