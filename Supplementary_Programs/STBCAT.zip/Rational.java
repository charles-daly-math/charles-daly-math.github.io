//Importing Array and BigInteger which for some reason doesn't work in main...?
import java.util.Arrays;
import java.math.BigInteger;

public class Rational{
    public BigInteger num;
    public BigInteger den;
    public double app;
    public String strsymb;
    
    ////////////////////////////////////////////////
    //   Some ways of constructing rationals  //////
    ////////////////////////////////////////////////
    
    //With two big integers
    public Rational(BigInteger pnum, BigInteger pdenom){
        int check = pdenom.signum();
        BigInteger tgcd = pnum.gcd(pdenom);
        //Checks if denom is zero
        if (check == 0){
            throw new IllegalArgumentException("Rational ill-defined");
        }
        //Ensures denominator is always positive
        else if(check == -1){
            this.num = (pnum.divide(tgcd)).negate();
            this.den = (pdenom.divide(tgcd)).negate();
        }
        else{
            this.num = pnum.divide(tgcd);
            this.den = pdenom.divide(tgcd);
        }
        
        //Calls approximation function
        this.app = approx(num, den);
        
        //Makes a string for the rational.
        String tempstr = "";
        tempstr = tempstr+String.valueOf(num)+"/"+String.valueOf(den);
        this.strsymb = tempstr;
    }
    
    //With two (normal) integers
    public Rational(int inum, int idenom){
        //Casts as BigIntegers
        BigInteger pnum = BigInteger.valueOf(inum);
        BigInteger pdenom = BigInteger.valueOf(idenom);
        
        //Redoes above
        int check = pdenom.signum();
        BigInteger tgcd = pnum.gcd(pdenom);
        //Checks if denom is zero
        if (check == 0){
            throw new IllegalArgumentException("Rational ill-defined");
        }
        //Ensures denominator is always positive
        else if(check == -1){
            this.num = (pnum.divide(tgcd)).negate();
            this.den = (pdenom.divide(tgcd)).negate();
        }
        else{
            this.num = pnum.divide(tgcd);
            this.den = pdenom.divide(tgcd);
        }
        
        //Approximate ratio
        this.app = (num.doubleValue())/(den.doubleValue());
        
        //Makes a string for the rational.
        String tempstr = "";
        tempstr = tempstr+String.valueOf(num)+"/"+String.valueOf(den);
        this.strsymb = tempstr;
    }
    
    //With two strings
    public Rational(String strnum, String strden){
        //Casts as BigIntegers
        BigInteger pnum = new BigInteger(strnum);
        BigInteger pdenom = new BigInteger(strden);
        
        //Redoes above
        int check = pdenom.signum();
        BigInteger tgcd = pnum.gcd(pdenom);
        //Checks if denom is zero
        if (check == 0){
            throw new IllegalArgumentException("Rational ill-defined");
        }
        //Ensures denominator is always positive
        else if(check == -1){
            this.num = (pnum.divide(tgcd)).negate();
            this.den = (pdenom.divide(tgcd)).negate();
        }
        else{
            this.num = pnum.divide(tgcd);
            this.den = pdenom.divide(tgcd);
        }
        
        //Approximate ratio
        this.app = (num.doubleValue())/(den.doubleValue());
        
        //Makes a string for the rational.
        String tempstr = "";
        tempstr = tempstr+String.valueOf(num)+"/"+String.valueOf(den);
        this.strsymb = tempstr;
    }
        
        //With a single string of the form "+-int1/int2"
        public Rational(String strfrac){
            //Splits string into two
            String[] numden = strfrac.split("/");
            
            //Defines numerator and denomator as strings.  If no /, just assumes integer.
            String strnum = numden[0];
            String strden = (numden.length == 1) ? "1" : numden[1];
            
            
            //Casts as BigIntegers
            BigInteger pnum = new BigInteger(strnum);
            BigInteger pdenom = new BigInteger(strden);

            //Redoes above
            int check = pdenom.signum();
            BigInteger tgcd = pnum.gcd(pdenom);
            //Checks if denom is zero
            if (check == 0){
                throw new IllegalArgumentException("Rational ill-defined");
            }
            //Ensures denominator is always positive
            else if(check == -1){
                this.num = (pnum.divide(tgcd)).negate();
                this.den = (pdenom.divide(tgcd)).negate();
            }
            else{
                this.num = pnum.divide(tgcd);
                this.den = pdenom.divide(tgcd);
            }

            //Calls approximation function
            this.app = approx(num, den);
            
            //Makes a string for the rational.
            String tempstr = "";
            tempstr = tempstr+String.valueOf(num)+"/"+String.valueOf(den);
            this.strsymb = tempstr;
    }

    //With single BigInteger
    public Rational(BigInteger pnum){
        //Writes as n/1
        this.num = pnum;
        this.den = BigInteger.ONE;
        
        //Calls approximation function
        this.app = approx(num, BigInteger.ONE);
        
        //Makes a string for the rational.
        String tempstr = "";
        tempstr = tempstr+String.valueOf(num)+"/"+String.valueOf(den);
        this.strsymb = tempstr;
    }
    
    //With a single (normal) integer
    public Rational(int inum){
        //Write as n/1
        this.num = BigInteger.valueOf(inum);
        this.den = BigInteger.ONE;
        
        //Approximate ratio
        this.app = (num.doubleValue())/(den.doubleValue());
        
        //Makes a string for the rational.
        String tempstr = "";
        tempstr = tempstr+String.valueOf(num)+"/"+String.valueOf(den);
        this.strsymb = tempstr;
    }
    
    //Defaults to zero
    public Rational(){
        //Write as 0/1
        this.num = BigInteger.ZERO;
        this.den = BigInteger.ONE;
        
        //Approximate
        this.app = 0.0;
        
        //Makes a string for the rational.
        String tempstr = "";
        tempstr = tempstr+String.valueOf(num)+"/"+String.valueOf(den);
        this.strsymb = tempstr;
    }
    
    
    
    ////////////////////////////////////////////////////////
    //////   Some ways of doing stuff with rationals  //////
    ///////////////////////////////////////////////////////
    
    //Addition of two rationals
    public static Rational add(Rational r1, Rational r2){
        BigInteger term1 = (r1.num).multiply(r2.den);
        BigInteger term2 = (r2.num).multiply(r1.den);
        BigInteger term3 = (r1.den).multiply(r2.den);
        return new Rational(term1.add(term2),term3);
    }
    
    //Substraction of two rationals
    public static Rational sub(Rational r1, Rational r2){
        BigInteger term1 = (r1.num).multiply(r2.den);
        BigInteger term2 = (r2.num).multiply(r1.den);
        BigInteger term3 = (r1.den).multiply(r2.den);
        return new Rational(term1.subtract(term2),term3);
    }
    
    //Addition of n-rationals
    public static Rational add(Rational[] rlist){
        Rational sum = new Rational();
        int nr = rlist.length;
        for(int i = 0; i < nr; i++){
            sum = add(sum, rlist[i]);
        }
        return sum;
    }
    
    //Multiplication of two rationals
    public static Rational mult(Rational r1, Rational r2){
        return new Rational((r1.num).multiply(r2.num),(r1.den).multiply(r2.den));
    }
    
    //Multiplies n-rationals
    public static Rational mult(Rational[] rlist){
        Rational prod = new Rational(1);
        int nr = rlist.length;
        for(int i =0; i < nr; i++){
            prod = mult(prod, rlist[i]);
        }
        return prod;
    }
    
    //Inversion
    public static Rational inv(Rational r1){
        if(r1.num == BigInteger.ZERO){
            throw new NumberFormatException("you are dividing by zero!");
        }
        return new Rational(r1.den, r1.num);
    }
    
    //Division
    public static Rational div(Rational r1, Rational r2){
        if(iszero(r2) == true){
            throw new NumberFormatException("you are dividing by zero!");
        }
        return new Rational((r1.num).multiply(r2.den),(r1.den).multiply(r2.num));
    }
    
    //Returns n-th power of a rational
    public static Rational power(Rational r, int n){
        Rational[] nlistofr = new Rational[Math.abs(n)];
        if(n > 0){
            Arrays.fill(nlistofr, r);
            return mult(nlistofr);
        }
        else if(n < 0){
            if(iszero(r) == true){
                throw new NumberFormatException("you are dividing by zero!");
            }
            Arrays.fill(nlistofr, inv(r));
            return mult(nlistofr);
        }
        else{
            return new Rational(1);
        }
    }
    
    //Negative
    public static Rational neg(Rational r1){
        return new Rational((r1.num).negate(),(r1.den));
    }
    
    //Checks if (strictly) positive.
    public static Boolean pos(Rational r1){
        if ((r1.num).signum() > 0){
            return true;
        }
        else{
            return false;
        }
    }
    
    //Checks if zero
    public static Boolean iszero(Rational r1){
        if (r1.num == BigInteger.ZERO){
            return true;
        }
        else{
            return false;
        }
    }
    
    //Checks two rationals are equal
    public static Boolean isequal(Rational r1, Rational r2){
        Rational diff = sub(r1, r2);
        return diff.iszero(diff);
    }
    
    //Checks if one
    public static Boolean isone(Rational r1){
        Rational tr = sub(new Rational(1), r1);
        return tr.iszero(tr);
    }
    
    //Checks if (strictly) negative
    public static Boolean isneg(Rational r1){
        if ((r1.num).signum() < 0){
            return true;
        }
        else{
            return false;
        }
    }
    
    //Checks if between 0 and 1
    public static Boolean incbet01(Rational r1){
        Rational r2 = sub(new Rational(1), r1);
        if ((r1.pos(r1) == true) && (r2.pos(r2) == true)){
            return true;
        }
        else{
            return false;
        }
    }
    
    //Returns an approximate of a big integer
    public static double approx(BigInteger tnum, BigInteger tden){
        //Remembers is positive or negative.
        double posorneg = (double) (tnum.signum());
        
        //Bits of numerator and denominator (and making sure numerator positive)
        tnum = tnum.abs();
        int bitnum = tnum.bitLength();
        int bitden = tden.bitLength();
        
        //Only care about the largest bits
        int shift = Math.max(bitnum,bitden)-1023;
        if(shift > 0){
            tnum = tnum.shiftRight(shift);
            tden = tden.shiftRight(shift);
        }
        return (posorneg)*(tnum.doubleValue())/(tden.doubleValue());
    }
    
    //Eats up a rational p/q and writes it as (k*q) + r where r is a rational between [0,1) and k is an integer.  Returns (k,r);
    public static Rational[] divrem(Rational rat1){
        //Gets numerator and denominator
        BigInteger top = (rat1.num);
        BigInteger bot = (rat1.den);
        //Does some division
        BigInteger[] qandr = top.divideAndRemainder(bot);
        //Integer and remainder part (could be negative remainder)
        Rational tempintpart = new Rational(qandr[0]);
        Rational tempremain = new Rational(qandr[1],bot);
        //Ensures remainder part is positive
        Rational intpart = (top.signum() < 0) ? (sub(tempintpart, new Rational(1))) : tempintpart;
        Rational remain = (top.signum() < 0) ? (add(tempremain, new Rational(1))) : tempremain;
        return new Rational[] {intpart, remain};
    }
    
    
    
    
    
    ///This method ensures that the fundamental domain given by the vertices is convex and positively oriented as in Equation 3.9
    
    public static Boolean convexcheck(Rational pk1, Rational pk2){
        Rational tk1 = pk1;
        Rational tk2 = pk2;
        //k1*k2
        Rational tk1k2 = Rational.mult(tk1,tk2);
        //k1 + k2
        Rational tsum = Rational.add(tk1,tk2);
        //k1 - k2
        Rational tdiff = Rational.sub(tk1,tk2);
        
        //2
        Rational two = new Rational(2);
        //k1k2*(k1+k2)
        Rational term1 = Rational.mult(tk1k2,tsum);
        //k1k2*(k1-k2)
        Rational term2 = Rational.mult(tk1k2,tdiff);
        
        //2-k1k2*(k1+k2)
        Rational sum1 = Rational.sub(two,term1);
        //2-k1k2*(k1-k2)
        Rational sum2 = Rational.sub(two,term2);
        //2+k1k2*(k1+k2)
        Rational sum3 = Rational.add(two,term1);
        //2+k1k2*(k1-k2)
        Rational sum4 = Rational.add(two,term2);

        //Booleans to check
        Boolean turn1 = Rational.pos(sum1);
        Boolean turn2 = Rational.pos(sum2);
        Boolean turn3 = Rational.pos(sum3);
        Boolean turn4 = Rational.pos(sum4);
        
        Boolean turningsame = ((turn1) && (turn2) && (turn3) && (turn4));
        
        //If either signed products are positive, meaning no self intersection nor degenerated quadliterals becoming triangles, then returns true.
        if(turningsame == true){
            return true;
        }
        else{
            return false;
        }
    }

    //Returns the rational as a string
    public String toString(){
        return (this.strsymb);
    }
    
    //Prints a rational
    public void print(){
        String snum = num.toString();
        String sden = den.toString();
        System.out.println("Your rational is "+snum+"/"+sden+" and is approximately "+app+".");
    }
    
}