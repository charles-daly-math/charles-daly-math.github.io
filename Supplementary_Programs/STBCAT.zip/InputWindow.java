import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.geom.*;

//Importing Array which for some reason doesn't work in main...?
import java.util.Arrays;

public class InputWindow extends JPanel implements ActionListener{
    
    //Windows
    Window win1;
    Window win2;

    //Parameters from the input window relevant to making particles
    
    //K-parameters
    public Rational iwk1;
    public Rational iwk2;
    public Rational iwk3;
    public Rational iwk4;
    
    //anchor-parameters
    public int iwn1;
    public int iwm1;
    public int iwn2;
    public int iwm2;
    
    //side-parameters
    public int iws1;
    public int iws2;
    
    //pararameter-parameters
    public Rational iwp1;
    public Rational iwp2;
    
    //direction-parameters
    public RVector iwd1;
    public RVector iwd2;
    
    //number of iterates
    public int iwnoits;
    
    //Some variables defining the input window
    public static double windowsize = 1050.0;
    public static double height = windowsize/7;
    
    //Variable for a button
    public static JButton button1;
        
    //Sets value for k1...k4
    public static JTextField kfield1;
    public static JTextField kfield2;
    public static JTextField kfield3;
    public static JTextField kfield4;
    
    //Sets values for Particle anchors
    public static JTextField afield1;
    public static JTextField afield2;
    public static JTextField afield3;
    public static JTextField afield4;
    
    //Sets values for sides to begin on
    public static JTextField sfield1;
    public static JTextField sfield2;
    
    //Sets values for parameter to begin on
    public static JTextField pfield1;
    public static JTextField pfield2;
    
    //Sets values for initial direction
    public static JTextField dfield1;
    public static JTextField dfield2;
    public static JTextField dfield3;
    public static JTextField dfield4;

    //Sets values of number of iterates
    public static JTextField noitsfield;
    
    //Adding stuff to window
    public InputWindow(Particle iwp1, Particle iwp2, int iwnoits){
        this.setBackground(Color.WHITE);
        this.setPreferredSize(new Dimension((int) windowsize, (int) height));
        this.setLayout(new GridLayout(2, 7));
        
        //Adding text fields for ks
        this.kfield1 = new JTextField((iwp1.k1).strsymb);
        kfield1.setColumns(4);
        this.add(new JLabel("k1:"));
        this.add(kfield1);
        
        this.kfield2 = new JTextField((iwp1.k2).strsymb);
        kfield2.setColumns(4);
        this.add(new JLabel("k2:"));
        this.add(kfield2);
        
        this.kfield3 = new JTextField((iwp2.k1).strsymb);
        kfield3.setColumns(4);
        this.add(new JLabel("k3:"));
        this.add(kfield3);
        
        this.kfield4 = new JTextField((iwp2.k2).strsymb);
        kfield4.setColumns(4);
        this.add(new JLabel("k4:"));
        this.add(kfield4);
        
        
        //Adding text fields for anchors
        this.afield1 = new JTextField(Integer.toString((iwp1.na)));
        afield1.setColumns(4);
        this.add(new JLabel("anchor n1:"));
        this.add(afield1);
        
        this.afield2 = new JTextField(Integer.toString((iwp1.ma)));
        afield2.setColumns(4);
        this.add(new JLabel("anchor m1:"));
        this.add(afield2);
        
        this.afield3 = new JTextField(Integer.toString((iwp2.na)));
        afield3.setColumns(4);
        this.add(new JLabel("anchor n2:"));
        this.add(afield3);
        
        this.afield4 = new JTextField(Integer.toString((iwp2.ma)));
        afield4.setColumns(4);
        this.add(new JLabel("anchor m2:"));
        this.add(afield4);
        
        
        
        
        //Adding text fields for sides of particles
        this.sfield1 = new JTextField(Integer.toString((iwp1.type)));
        sfield1.setColumns(3);
        this.add(new JLabel("vi:"));
        this.add(sfield1);
        
        this.sfield2 = new JTextField(Integer.toString((iwp2.type)));
        sfield2.setColumns(3);
        this.add(new JLabel("wi:"));
        this.add(sfield2);
        
        
        
        
        //Adding text fields for parameters
        this.pfield1 = new JTextField((iwp1.spar).strsymb);
        pfield1.setColumns(4);
        this.add(new JLabel("affine par1:"));
        this.add(pfield1);
        
        this.pfield2 = new JTextField((iwp2.spar).strsymb);
        pfield2.setColumns(4);
        this.add(new JLabel("affine par2:"));
        this.add(pfield2);
        
        
        
        
        
        //Adding text field for noits;
        this.noitsfield = new JTextField(Integer.toString((iwnoits)));
        noitsfield.setColumns(4);
        this.add(new JLabel("iterations:"));
        this.add(noitsfield);
        
        //Adds buttons, makes clickable
        this.button1 = new JButton("Go");
        this.add(button1);
        button1.addActionListener(this);
    }
    

    
    //Action commands for clicking button
    public void actionPerformed(ActionEvent e){
        
        if (e.getSource() == button1){
            
            /////////////////////////////////////////
            /////CHECK TO MAKE SURE INPUT IS LEGIT////
            /////////////////////////////////////////
            
            try{
            //Sets k-parameters
            Rational twk1 = new Rational(kfield1.getText());
            Rational twk2 = new Rational(kfield2.getText());
            Rational twk3 = new Rational(kfield3.getText());
            Rational twk4 = new Rational(kfield4.getText()); 

            //Sets anchor-parameters
            int twn1 = Integer.parseInt(afield1.getText());
            int twm1 = Integer.parseInt(afield2.getText());
            int twn2 = Integer.parseInt(afield3.getText());
            int twm2 = Integer.parseInt(afield4.getText());

            //Sets side parameters
            int tws1 = Integer.parseInt(sfield1.getText());
            int tws2 = Integer.parseInt(sfield2.getText());

            //Sets parameter fields
            Rational twp1 = new Rational(pfield1.getText());
            Rational twp2 = new Rational(pfield2.getText());

            //Sets direction fields
            RVector twd1 = Particle.ogdir(twk1, twk2, twn1, twm1, tws1);
            RVector twd2 = Particle.ogdir(twk3, twk4, twn2, twm2, tws2);

            //Sets number of its
            int twnoits = Integer.parseInt(noitsfield.getText());
            
            //Sets coefficients to inputs
            Particle p1 = new Particle(twk1, twk2, twn1, twm1, tws1, twp1, twd1);
            Particle q1 = new Particle(twk3, twk4, twn2, twm2, tws2, twp2, twd2);
            
            //Constructs the pairs of points over the iterations
            PointPairs npointpairs = new PointPairs(p1, q1, twnoits);

            //Sets ppoints and qpoints to each window
            win1.pplist = npointpairs;
            win2.pplist = npointpairs;
        
            }
            
            
            //Catches number format errors from Particle.java
            catch (NumberFormatException nfe){
                System.out.println(nfe.getMessage());
            }
            
            //Repaints both windows
            win1.repaint();
            win2.repaint();   

            }
            
            
        }
    
}