//Importing Array which for some reason doesn't work in main...?
import java.util.Arrays;

public class RVector{
    public Rational z1;
    public Rational z2;
    public Vector vapp;
    
    ///////////////////////////////////////////////////
    /////   Some ways of constructing RVectors  //////
    //////////////////////////////////////////////////
    
    //Makes a 2x1 zero vector;
    public RVector(){
        this.z1 = new Rational();
        this.z2 = new Rational();
        this.vapp = new Vector(new double[] {z1.app, z2.app});
    }
    
    //Makes a 2x1 rational vector from two rationals;
    public RVector(Rational pz1, Rational pz2){
        this.z1 = pz1;
        this.z2 = pz2;
        this.vapp = new Vector(new double[] {z1.app, z2.app});
    }
    
    //Makes a 2x1 rational vector from two integers;
    public RVector(int pz1, int pz2){
        this.z1 = new Rational(pz1);
        this.z2 = new Rational(pz2);
        this.vapp = new Vector(new double[] {z1.app, z2.app});
    }
    
    //Makes a 2x1 rational vector from a 2x1 vector of rationals;
    public RVector(Rational[] rvec){
        this.z1 = rvec[0];
        this.z2 = rvec[1];
        this.vapp = new Vector(new double[] {z1.app, z2.app});
    }
    
    //Makes a 2x1 rational vector from two strings;
    public RVector(String str1, String str2){
        this.z1 = new Rational(str1);
        this.z2 = new Rational(str2);
        this.vapp = new Vector(new double[] {z1.app, z2.app});
    }
    
    
    
    ///////////////////////////////////////////////////
    /////   Methods for doing stuff to RVectors  //////
    //////////////////////////////////////////////////
      
    //Multiplies a rational vector by a rational
    public static RVector scale(Rational s, RVector rv){
        RVector u = new RVector(
            s.mult(s, rv.z1), s.mult(s, rv.z2)
        );
        return u;
    }
    
    //Adds two rational vectors
    public static RVector add(RVector v, RVector w){
        RVector u = new RVector(
            (v.z1).add(v.z1, w.z1), (v.z1).add(v.z2, w.z2)
        );
        return u;
    }
    
    //Subtracts two rational vectors
    public static RVector sub(RVector v, RVector w){
        RVector u = new RVector(
            (v.z1).sub(v.z1, w.z1), (v.z1).sub(v.z2, w.z2)
        );
        return u;
    }
    
    //Adds a bunch of rational vectors
    public static RVector add(RVector[] vlist){
        RVector sum = new RVector();
        int nv = vlist.length;
        for(int i=0; i < nv; i++){
            sum = add(sum, vlist[i]);
        }
        return sum;
    }
    
    //Does a linear combination of rationals and vectors
    public static RVector lincomb(Rational[] rats, RVector[] vlist){
    //Checks if same size
        if (rats.length != vlist.length){
            throw new IllegalArgumentException("coefficients and rationals are not the same size");
            }
        RVector[] summands = new RVector[rats.length];
        Arrays.setAll(summands, i -> scale(rats[i], vlist[i]));
        return add(summands);
    }
    
    //Affine combination of p1 and p2 with parameter s:  (1-s)p1 + sp2
    public static RVector affcomb(Rational s, RVector p1, RVector p2){
        RVector term1 = RVector.scale(Rational.sub(new Rational(1),s), p1);
        RVector term2 = RVector.scale(s, p2);
        return RVector.add(term1,term2);
    }
    
    //Projects a vector from R^{n+1} to R^{n}
    public static Vector proj(Vector v){
        Vector w = new Vector(v.size-1);
        for(int i=0;i<w.size; i++){
            w.data[i] = v.data[i];
        }
        
        return w;
    }
    
    //Does a dot product of two rational vectors
    public static Rational dot(RVector v1, RVector v2){
        Rational s1 = Rational.mult(v1.z1,v2.z1);
        Rational s2 = Rational.mult(v1.z2,v2.z2);
        return Rational.add(s1,s2);
    }
    
    //Returns negative of a vector
    public static RVector neg(RVector v1){
        return new RVector(Rational.neg(v1.z1), Rational.neg(v1.z2));
    }

    //Prints a rational vector
    public void print(){
        String z1n = (z1.num).toString();
        String z1d = (z1.den).toString();
        
        String z2n = (z2.num).toString();
        String z2d = (z2.den).toString();
        System.out.println("Your vector has coordinates: {"+z1n+"/"+z1d+" , "+z2n+"/"+z2d+"}");
        System.out.println("This is approximately {"+(vapp.data[0])+" , "+(vapp.data[1])+"}");
        System.out.println("");
    }
    
    
    ///////////////////////////////////////////////
    /////   Conditionals where on RVectors  //////
    /////////////////////////////////////////////
    
    //Expresses w in terms of v1 and v2
    public static RVector coefs(RVector v1, RVector v2, RVector w){
        RMatrix invRM = RMatrix.inv(new RMatrix(v1, v2));
        return RMatrix.linact(invRM, w);
    }
    
    
    //Makes a boolean where true means w lies in the upper halfplane, note this means for coef of v2 > 0 NOT v1.
    public static Boolean upper(RVector v1, RVector v2, RVector w){
        RMatrix rM = new RMatrix(v1, v2);
        Rational det = rM.det(rM);
        Rational s1 = RVector.dot(new RVector(Rational.neg(v1.z2), v1.z1), w);
        Rational s2 = Rational.div(s1,det);
        return Rational.pos(s2);
    }
    
    //Takes tangent, an old direction, and a proposed new direction, then orients it correctly
    public static RVector orient(RVector ptangent, RVector olddir, RVector propnewdir){
        if(upper(ptangent, olddir, propnewdir) == true){
            return propnewdir;
        }
        else{
            return RVector.neg(propnewdir);
        }
    }
    
    //Makes a boolean vector where true means positive and false means NON-NEGATIVE (could be zero!!)
    public static Boolean[] poscoords(RVector v1, RVector v2, RVector w){
        RVector coords = coefs(v1, v2, w);
        Boolean b1 = Rational.pos(coords.z1);
        Boolean b2 = Rational.pos(coords.z2);
        return new Boolean[] {b1, b2};
    }
    
 
    
}