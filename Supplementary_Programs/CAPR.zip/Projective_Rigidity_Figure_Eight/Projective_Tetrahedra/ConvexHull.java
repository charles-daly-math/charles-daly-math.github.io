public class ConvexHull{
    //Constructor
    public ConvexHull(){
    }
    
    //Produces the actual convex hull
    public Vector[] hull(Vector[] ogpoints){
        
        //Cleans list first
        Vector[] points = cleanList(ogpoints);
        
        if(points.length == 1){
            return points;
        }
        
        //Checks to see not just a line pretty much
        if(degenerate(points) < 0.00000001){
            return new Vector[] {points[0], points[1]};
        }
        
        //When it's not just a line.  
        else{
            //Makes a list of auxilary points
            Vector[] auxpoints = new Vector[points.length];
            int nop = points.length;

            //Left index will be the index in list points to determine the left most point
            //Count is an index that will go up with each boundary point of the convex hull
            int leftindex = 0;
            int count = 0;

            //Finds the left-most point in the list of points
            Vector left = points[0];
            for(int i = 0; i < nop; i++){
                if(points[i].data[0] < left.data[0]){
                    left = points[i];
                    leftindex = i;
                }
            }
            
            

            //Starts doing the gift wrapping with the left most point and the vector pointing upwards
            Vector startdir = new Vector(new double[] {0.0, 1.0});
            count = 1;
            auxpoints[0] = left;

            //Determines the nextPoint starting from the leftmost in the direction of (0,1).  While the nextPoint index doesn't equal the original, declare the next auxpoints the be determined by the input point and input starting direction.  The next start direction is determined by the difference of the two auxpoints which are the boundary points.  
            while(nextPoint(points, auxpoints[count-1], startdir) != leftindex){
                auxpoints[count] = points[nextPoint(points, auxpoints[count-1],startdir)];
                startdir = auxpoints[count].minus(auxpoints[count],auxpoints[count-1]);
                count = count + 1;
            }

            //Cleans up the list and spits out the convex hull points
            Vector[] fullpoints = new Vector[count];
            System.arraycopy(auxpoints, 0, fullpoints, 0, count);

            return fullpoints;
        }
    }
    
    //Makes a list of n random whose coordinates are between -1 and +1
    public Vector[] randomPoints(int n){
        Vector[] auxpoints = new Vector[n];
        Vector test = new Vector(1);
        for(int i = 0; i < n; i++){
            auxpoints[i] = new Vector(new double[] {-1+2*Math.random(),-1+2*Math.random()});
        }
        
        return auxpoints;
    }
    
    //Clean list
    public Vector[] cleanList(Vector[] input){
        double eps = 0.0000000001;
        boolean small = false;
        Vector test = new Vector(0);
        
        Vector[] auxpoints = new Vector[input.length];
        auxpoints[0] = input[0];
        int count = 0;
        
        for(int i =0; i < input.length; i++){
            test = input[i];
            //Test if any of the distances are really small
            for(int j = 0; j <= count; j++){
                if(auxpoints[j].norm(auxpoints[j].minus(auxpoints[j],test)) < eps){
                    small = true;
                    break;
                }
            }
            
            if(small == false){
                count = count + 1;
                auxpoints[count] = test;
            }
            
            else{
                //Resets small and skips this point
                small = false;
            }
            
        }
        
        //Cleans up the list and spits out the convex hull points
        Vector[] fullpoints = new Vector[count+1];
        System.arraycopy(auxpoints, 0, fullpoints, 0, count+1);
        
        return fullpoints;
    }
    
    //Given a list of points, a starting position, and a direction, determines the point in the list of points that is closest to the line eminanting from start in the provided direction.  Spits out the index in input.
    public int nextPoint(Vector[] input, Vector start, Vector direction){
        int index = 0;
        double measure = 2;
        double test = 0;
        Vector b = new Vector(2);
        
        
        for(int i = 0; i < input.length; i++){
            b = input[i].minus(input[i],start);
            //The smaller test is, the closer the angle is to 0.  test will always be less or equal to 2.
            test = Math.abs(1-b.dot(b,direction)/(b.norm(b)*direction.norm(direction)));
            if(test <= measure){
                measure = test;
                index = i;
            }
        }
        
        return index;
    }
    
    //Checks to see if the list is degenerate
    public double degenerate(Vector[] input){
        int number = input.length;
        double d = 0.0;
        
        //If less than 3, just give back stuff
        if(input.length <= 2){
            return d;
        }
        
        //Otherwise check to see how much the points deviate from a line
        else{
            //Make a vector defining the line
            Vector line = input[0].minus(input[1],input[0]);
            Vector aux = new Vector(0);
            Vector ortho = new Vector(0);
            for(int i = 2; i< number; i++){
                aux = aux.minus(input[0],input[i]);
                ortho = aux.minus(aux,
                                  line.scale(aux.dot(aux,line)/line.dot(line,line),line)
                                  );
                d = d + ortho.dot(ortho,ortho);
            }
            
            return d;
        }
    }
    
    
    
}