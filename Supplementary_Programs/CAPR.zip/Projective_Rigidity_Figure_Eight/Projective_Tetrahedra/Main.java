import java.awt.*;
import javax.swing.*;
import java.util.*;

public class Main extends JPanel{
    public Main(){
    }
    
    public static void main(String[] args){
        //Makes frame, window, input window, and keyboard listener
        JFrame frame1 = new JFrame("This is a geodesic slice");
        JFrame frame2 = new JFrame("Put values of (t,z) here");
        
        //Sets scales for window
        Window window = new Window();
        window.R = 2.5;
        window.Org = new Vector(new double[] {0.0,0.0});
        
        
        ///////////////////////////////////////////////////
        // SETS THE ACTUAL INITIAL C    VALUES HERE   ////
        //////////////////////////////////////////////////
        
        //Sets slice height of window to -3.5 and t to 4
        window.c = -3.5;
        window.t = 4.0;
        
        //Input window
        InputWindow iw = new InputWindow();
        iw.w = window;
        
        //Makes the matrices
        window.makeMatrices();
        
        //Sets the equation ax+by+cz+dw = 1 for the affine patch
        
        ///////////////////////////////////////////////////
        // SETS THE ACTUAL INITIAL PATCH VALUES HERE   ////
        //////////////////////////////////////////////////
        
        
        //VERY SPECIAL PATCH
        window.P = new Vector(new double[] {-3.0/4.0,1.0/4.0,-1.0/2.0,3.0/16.0});
        
        //Introduces keyboard listerer for flying around
        KeyboardListener keys = new KeyboardListener();
        keys.w = window;
        keys.iw = iw;
        
        //Adds some stuff to frame2
        frame2.add(iw);
        frame2.setContentPane(iw);
        frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame2.pack();
        frame2.setVisible(true);
        frame2.setResizable(false);
        frame2.setLocation((int) window.screensize,0);
        
        //Adds some stuff above to frame1.
        frame1.add(window);
        frame1.addKeyListener(keys);
        frame1.setContentPane(window);
        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame1.pack();
        frame1.setVisible(true);
        frame1.setResizable(false);

        
    }
}