public class Vector{
    public double[] data;
    public int size;
    
    //Makes a nx1 zero vector;
    public Vector(int n){
        this.data = new double[n];
        this.size = n;
        for(int i =0; i < n; i++){
            this.data[i] = 0.0;
        }
    }
    
    //Makes a nx1 vector from data;
    public Vector(double[] list){
        this.size = list.length;
        this.data = new double[list.length];
        for(int i =0; i < list.length; i++){
            this.data[i] = list[i];
        }
    }
    
    //Make a random integer matrix with entries from 0 to m
    public static Vector randVector(int n, int m){
        Vector vec = new Vector(n);
        for(int i =0; i < n; i++){
            vec.data[i] = (int) ((m+1)*Math.random());
        }
        
        return vec;
    }

    
    //Multiplies a vector by a constant
    public static Vector scale(double s, Vector v){
        Vector u = new Vector(v.size);
        for(int i =0; i < v.size; i++){
            u.data[i] = s*v.data[i];
        }
        return u;
    }
    
    //Adds two vector together
    public static Vector plus(Vector v, Vector w){
        //Checks if same size
        if (v.size != w.size){
            throw new IllegalArgumentException("Matrix and vector not the same size");
        }
        
        Vector u = new Vector(v.size);
        for(int i =0; i<v.size; i++){
            u.data[i] = v.data[i] + w.data[i];
        }
        
        return u;
    }
    
    //Subtracts two vectors
    public static Vector minus(Vector v, Vector w){
        //Checks if same size
        if (v.size != w.size){
            throw new IllegalArgumentException("Matrix and vector not the same size");
        }
        
        return plus(v,scale(-1.0,w));
    }
    
    //Appends to a vector to another vector
    public static Vector app(Vector v, Vector w){
        Vector u = new Vector(v.size+w.size);
        u.size = v.size + w.size;
        
        for(int i=0; i < v.size; i++){
            u.data[i] = v.data[i];
        }
        
        for(int i =v.size; i < u.size; i++){
            u.data[i] = w.data[i-v.size];
        }
        
        return u;
    }
    
    //Appends a single double to a vector
    public static Vector app(Vector v, double d){
        return v.app(v, new Vector(new double[] {d}));
    }
    
    //Returns a linear combination of vectors {v1,v2,...,vn} with weights {c1,c2,...,cn}
    public static Vector lincomb(double[] scalars, Vector[] vlist){
        //Checks if same size
        if (scalars.length != vlist.length){
            throw new IllegalArgumentException("Matrix and vector not the same size");
        }
        
        //Should probably check each vector same size...
        Vector w = new Vector(vlist[0].size);
        for(int i = 0; i < scalars.length; i++){
            w = plus(w,scale(scalars[i],vlist[i]));
        }
        
        return w;
    }
    
    //Projects a vector from R^{n+1} to R^{n}
    public static Vector proj(Vector v){
        Vector w = new Vector(v.size-1);
        for(int i=0;i<w.size; i++){
            w.data[i] = v.data[i];
        }
        
        return w;
    }
    
    //Multiplies a matrix and a vector 
    public static Vector mult(Matrix A, Vector v){
        //Checks if same size
        if (A.size != v.size){
            throw new IllegalArgumentException("Matrix and vector not the same size");
        }
        
        //Multiplies entries adds up
        Vector w = new Vector(A.size);
        w.size = A.size;
        for(int i = 0; i < A.size; i++){
            for(int j = 0; j < A.size; j++){
                w.data[i] = w.data[i]+A.data[i][j]*v.data[j];
            }
        }
        
        return w;
    }
    
    //Returns dot product
    public static double dot(Vector v, Vector w){
        //Checks if right size
        if (w.size != v.size){
            throw new IllegalArgumentException("Vectors must be same size");
        }
        double d = 0;
        for(int i =0; i < v.size; i++){
            d = d + v.data[i]*w.data[i];
        }
        return d;
    }
    
    //Returns norm
    public static double norm(Vector v){
        return Math.sqrt(dot(v,v));
    }
    
    //Matrix acts on vector in an affine patch defined by a1x1 + a2x2 + ... + anxn = 1.  Let k be the first index where ai != 0.  Let P = (a1,a2,...,an) and write Q = (a1,a2,...ak-1,ak+1,...an) and v = (x1,x2,...xk-1,xk+1,...xn).  
    public static Vector act(Matrix A, Vector v, Vector P){
        //Checks if right size
        if ((A.size != v.size+1) || (P.size != v.size + 1)){
            throw new IllegalArgumentException("Matrix must be (n+1)x(n+1), Vector v is nx1, and Vector P is (n+1)x1");
        }
        
        //Checks which entry of P is non-zero.  Call this index k
        int nonzero = 0;
        double ak = 0.0;
        for(int i = 0; i < P.size; i++){
            if(P.data[i] != 0){
                nonzero = i;
                ak = P.data[nonzero];
                break;
            }
        }
        
        //Makes new a new vector Q = (a1,a2,...ak-1,ak+1,...an) 
        Vector Q = new Vector(P.size-1);
        Q.size = P.size - 1;
        for(int i = 0; i < Q.size; i++){
            if(i < nonzero){
                Q.data[i] = P.data[i];
            }
            else{
                Q.data[i] = P.data[i+1];
            }
        }
        
        
        //Makes a new vector u = (ak*x1,ak*x2,...,ak*xk-1,(1-dot(Q,v)),ak*xk+1,...,ak*xn)
        Vector u = new Vector(v.size+1);
        u.size = v.size +1;
        for(int i = 0; i < u.size; i++){
            if(i < nonzero){
                u.data[i] = ak*v.data[i];
            }
            else if(i > nonzero){
                u.data[i] = ak*v.data[i-1];
            }
            else{
                u.data[i] = 1-dot(Q,v);
            }
        }
        
        
        
        
        
        
        //Takes our vector u and applies A to it.
        Vector w = mult(A,u);
        w = w.scale(1.0/dot(w,P),w);
        
        Vector s = new Vector(v.size);
        s.size = v.size;
        
        //Returns final vector
        for(int i = 0; i < s.size; i++){
            if(i < nonzero){
                s.data[i] = w.data[i];
            }
            else{
                s.data[i] = w.data[i+1];
            }
        }
        
        return s;
        
    }
    
    

    
    //Prints a vector
    public void print(){
        System.out.println("Your vector has coordinates");
        String str = "{";
        for(int i =0; i < size; i++){
            if((i != size-1) && (i != 0)){
                str = str+" , "+data[i];
            }
            else if(i == 0){
                str = str+data[i];
            }
            else{
                str = str+" , "+data[i]+"}";
            }
        }
        System.out.println(str);
    }
    
    
    
}