public class Tetrahedron{
    public Vector u;
    public Vector v;
    public Vector w;
    public Vector h;
    
    //Makes the standard tetrahedron in R^{3}
    public Tetrahedron(){
        this.u = new Vector(new double[] {0.0,0.0,0.0});
        this.v = new Vector(new double[] {1.0,0.0,0.0});
        this.w = new Vector(new double[] {0.0,1.0,0.0});
        this.h = new Vector(new double[] {0.0,0.0,1.0});
    }
    
    //Makes the scaled standard tetrahedron in R^{3}
    public Tetrahedron(double s){
        this.u = new Vector(new double[] {0.0,0.0,0.0});
        this.v = new Vector(new double[] {s,0.0,0.0});
        this.w = new Vector(new double[] {0.0,s,0.0});
        this.h = new Vector(new double[] {0.0,0.0,s});
    }
    
    //Gives you a tetrahedron in R^{3} ordered by {u,v,w,h}
    public Tetrahedron(Vector a, Vector b, Vector c, Vector d){
        this.u = a;
        this.v = b;
        this.w = c;
        this.h = d;
    }
    
    //Matrix acts on tetrahedron in R^{n}
    public static Tetrahedron act(Matrix A, Tetrahedron T, Vector P){
        Tetrahedron tetra = new Tetrahedron();
        tetra.u = T.u.act(A, T.u, P);
        tetra.v = T.v.act(A, T.v, P);
        tetra.w = T.w.act(A, T.w, P);
        tetra.h = T.h.act(A, T.h, P);
        
        return tetra;
    } 
    
    //Finds intersections of plane z = c and the line segment between two vectors A and B
    public static Vector intersect(Vector A, Vector B, double c){
        
        //If A and B are on the same z-slice
        if(A.data[2] == B.data[2]){
            //If A.z == c, return A
            if(A.data[2] == c){
                return A;
            }
            //Otherwise return trivial
            else{
                return new Vector(1);
            }
        }
        
        else{
            double a = (c-A.data[2])/(B.data[2]-A.data[2]);
            if(a<0 || 1<a){
                //Returns trivial
                return new Vector(1);
            }
            else{
                //Returns actual intersection
                Vector BA = B.minus(B,A);
                return A.proj(A.plus(A,A.scale(a,BA)));
            }
        }
    }
    
    //Looks at a tetrahedron and a plane z = c, then returns all points of intersection.
    public static Vector[] poi(Tetrahedron T, double c){
        Vector[] vertices = new Vector[] {T.u, T.v, T.w, T.h};
        Vector[] points = new Vector[6];
        int nop = 0;
        
        for(int i=0; i<4; i++){
            for(int j=i+1; j<4; j++){
                //Checks if intersection is trivial, i.e. vector length 1
                if(intersect(vertices[i], vertices[j], c).size != 1){
                    points[nop] = intersect(vertices[i], vertices[j], c);
                    nop = nop + 1;
                }
            }
        }
        
        //If number of intersections is 3
        if(nop == 3){
            return new Vector[] {points[0],points[1],points[2]};
        }

        //If number of intersections if 4
        else if(nop == 4){   
            return new Vector[] {points[0], points[1], points[2], points[3]};
        }
    
        //If number of intersections neither return a single vector with a single entry
        else{
            return new Vector[] {new Vector(1)};
        }
    } 
    
    

    
    
        
    //Prints Tetrahdeon Coordinates
    public void print(){
        System.out.println("Your tetrahedron has coordinates");
        System.out.println("u = { "+u.data[0]+" , "+u.data[1]+" , "+u.data[2]+" };");
        System.out.println("v = { "+v.data[0]+" , "+v.data[1]+" , "+v.data[2]+" };");
        System.out.println("w = { "+w.data[0]+" , "+w.data[1]+" , "+w.data[2]+" };");
        System.out.println("t = { "+h.data[0]+" , "+h.data[1]+" , "+h.data[2]+" };");
        System.out.println("");
    }
    
}