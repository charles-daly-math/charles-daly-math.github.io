public class Matrix{
    public double[][] data;
    public int size;
    
    //Makes an nxn identity matrix
    public Matrix(int n) {
        this.data = new double[n][n];
        this.size = n;
        for(int i =0; i < n; i++){
            this.data[i][i] = 1.0;
        }
    }
    
    //Makes an 1x1 identity matrix
    public Matrix() {
        this.data = new double[1][1];
        this.data[0][0] = 1.0;
        this.size = 1;
    }
    
    //Makes a nxn random integer matrix with entries from 0 to m
    public static Matrix randMatrix(int n, int m){
        Matrix mat = new Matrix(n);
        for(int i =0; i < n; i++){
            for(int j=0; j<n; j++){
                mat.data[i][j] = (int) ((m+1)*Math.random());
            }
        }
        return mat;
    }
    
    //Checks is square
    public static int checkSize(Matrix A){
        int n = A.size;
        int check = 0;
        for (int i=0; i<n; i++){
            if(n != A.data[i].length){
                check = 1;
            }
        }
        return check;
    }
    
    //Makes a matrix with input data
    public Matrix(double[][] entries){
        this.size = entries.length;
        
        //Checks if size correct
        int check = 0;
        for (int i = 0; i < size; i ++){
            if(entries.length != entries[i].length){
                check = 1;
            }
        }
        
        //Returns wrong size
        if(check == 1){
            throw new IllegalArgumentException("Matrix isn't square.");
        }
        
        //If size correct, makes matrix
        else{
            this.data = new double[size][size];
            for(int i =0; i < size; i++){
                for(int j = 0; j < size; j++){
                    this.data[i][j] = entries[i][j];
                }
            }
        }
    }
    
    //Makes a matrix with input vectors
    public Matrix(Vector[] vlist){
        this.size = vlist.length;
        this.data = new double[size][size];
        
        for(int i =0; i < vlist.length; i++){
            for(int j = 0; j < vlist.length; j++){
                this.data[i][j] = vlist[j].data[i];
            }
        }
    }
    
    //Makes transpose of a matrix
    public static Matrix transpose(Matrix A){
        int n = A.size;
        Matrix mat = new Matrix(n);
        for(int i = 0; i < n; i++){
            for(int j=0; j<n; j++){
                mat.data[i][j] = A.data[j][i]; 
            }
        }
        return mat;
    }
    
    //Summation of list of doubles
    public static double sum(Matrix A){
        double d = 0.0;
        for(int i = 0; i<A.size; i++){
            d = d + A.data[0][i]*det(A.cofactor(A,0,i));
        }
        return d;
    }
    
    //Determinant of a matrix
    public static double det(Matrix A) {
        if(A.size == 2){
            return (A.data[0][0]*A.data[1][1]-A.data[1][0]*A.data[0][1]);
        }
        
        double d = 0.0;
       
        for(int i = 0; i < A.size; i++){
            d = d + Math.pow(-1,i)*A.data[0][i]*det(A.cofactor(A,0,i));
        }
        
        return d;
    }
    
    //Trace of a matrix (RECURSIVE FOR EXAMPLE PURPOSE)
    public static double tr(Matrix A){
        //A.print();
        if(A.size == 1){
            return A.data[0][0];
        }
        
        double trace = 0.0;
        trace = trace + A.data[0][0] + tr(A.cofactor(A,0,0));
        
        return trace;
    }
    
    //Product of two matrices
    public static Matrix mult(Matrix A, Matrix B){
        //Checks if right size
        if (A.size != B. size){
            throw new IllegalArgumentException("Not correct size");
        }
        
        //Makes new data and constructs by multiplication
        double[][] data = new double[A.size][A.size];
        for(int i = 0; i < A.size; i++){
            for(int j=0; j < A.size; j++){
                for(int k = 0; k < A.size; k++){
                    data[i][j] = data[i][j] + A.data[i][k]*B.data[k][j];
                }
            }
        }
        
        return new Matrix(data);
    }
    
    //Conjugate of two matrices
    public static Matrix conj(Matrix A, Matrix B){
        return B.mult(A.mult(B,A),B.inv(B));
    }
    
    //Add matrices
    public static Matrix add(Matrix A, Matrix B){
        //Checks same size
        if (A.size != B.size){
            throw new IllegalArgumentException("Not correct size");
        } 
        
        double[][] data = new double[A.size][A.size];
        //Makes new data and constructs by addition
        for(int i =0; i < A.size; i++){
            for(int j = 0; j < A.size; j++){
                data[i][j] = A.data[i][j] + B.data[i][j];
            }
        }
        
        return new Matrix(data);
    }
    
    //Scales matrices
    public static Matrix scale(double s, Matrix A){
        for(int i =0; i < A.size; i++){
            for(int j=0; j < A.size; j++){
                A.data[i][j] = s*A.data[i][j];
            }
        }
        return A;
    }
    
    //Subtract matrices
    public static Matrix sub(Matrix A, Matrix B){
        //Checks same size
        if (A.size != B.size){
            throw new IllegalArgumentException("Not correct size");
        }
        
        return add(A,scale(-1.0,B));
    }
    
    //Gets the (i,j)-th cofactor
    public static Matrix cofactor(Matrix A, int a, int b){
       
        int size = A.data.length-1;
        double[][] data = new double[size][size];

        for(int i = 0; i < size+1; i++){
            for(int j = 0; j < size + 1; j++){

                if((i < a) && (j < b)){
                    data[i][j] = A.data[i][j];
                }

                else if((i < a) && (b < j)){
                    data[i][j-1] = A.data[i][j];
                }

                else if((a < i) && (j < b)){
                    data[i-1][j] = A.data[i][j];
                }

                else if((a < i) && (b < j)){
                    data[i-1][j-1] = A.data[i][j];
                }
            }
        }
        
        return new Matrix(data);
    }
    
    //Returns inverse of a matrix
    public static Matrix inv(Matrix A){
        //Checks if det(A) is zero.
        if (det(A) == 0){
            throw new IllegalArgumentException("Determinant is zero, non-invertible");
        }
        
        double[][] data = new double[A.size][A.size];
        for(int i=0; i < A.size; i++){
            for(int j=0; j < A.size; j++){
                data[j][i] = Math.pow(-1,i+j)*det(cofactor(A,i,j))/det(A);
            }
        }
        return new Matrix(data);
    }
    
    //Returns a random n-fold product of matrices
    public static Matrix randProd(Matrix[] mlist, int n){
        Matrix m = new Matrix(mlist[0].size);
        int j = 0;
        for(int i = 0; i < n; i++){
            j = (int) (mlist.length*Math.random());
            m=mult(m,mlist[j]);
        }
        return m;
    }
    
    //Returns an m-length sequence of numbers from 0 to (n-1) to get from a list with n-elements.  
    public static int[] sequence(int n, int m){
        int[] aux = new int[m];
        for(int i =0; i<m; i++){
            aux[i] = (int) (n*Math.random());
        }
        
        return aux;
    }
    
    //Returns product of matrices
    public static Matrix mlistProd(Matrix[] mlist){
        Matrix m = new Matrix(mlist[0].size);
        for(int i =0; i < mlist.length; i++){
            m = mult(m,mlist[i]);
        }
        return m;
    }
    
    //Returns a product of matrices from a ordered list of generators and sequences of integers
    public static Matrix mlistProd(Matrix[] gens, int[] seq){
        Matrix[] mlist = new Matrix[seq.length];
        for(int i=0; i<seq.length; i++){
            mlist[i] = gens[seq[i]];
        }
        return mlistProd(mlist);
    }
    
    
    //Returns n-th power of a matrix
    public static Matrix power(Matrix A, int j){
        Matrix m = new Matrix(A.size);
        if(j == 0){
            return new Matrix(A.size);
        }
        else{
            for(int i =0; i < Math.abs(j); i++){
                m = mult(m,A);
            }
            if(j > 0){
                return m;
            }
            else{
                return inv(m);
            }
        }
    }
    
    //Returns a list of random matrices of size nom and depth n
    public static Matrix[] matList(Matrix[] gens, int nom, int n){
        Matrix[] mats = new Matrix[nom];
        int m = 0;
        
        for(int i =0; i < nom; i++){
            mats[i] = randProd(gens, n);
        }
        
        return mats;
    }
    
    
    
    //Returns a time-dependent family of random matrices of size nom and depth n.  The generators depend on a parameter t, which has m such values.  Matrix[][] is of the form Matrix[t][j] so each Matrix[t] = gens[t].
    public static Matrix[][] timedMatList(Matrix[][] gens, int nom, int m, int n){
        int genslength = gens[0].length;
        Matrix[][] aux = new Matrix[m][nom];
        int[] auxsequence = new int[n];
        for(int j=0; j< nom; j++){
            auxsequence = sequence(genslength, n);
            for(int i=0; i<m; i++){
                aux[i][j] = mlistProd(gens[i], auxsequence);
            }
        }
        
        return aux;
    }
    
    //Prints a matrix
    public void print(){
        System.out.println("Your matrix has entries");
        int m = size;
        String row = "{";
        for(int i=0; i < m; i++){
            row = row+"{";
            for(int j=0; j < m; j++){
                if(j != 0){
                    row = row+" , "+data[i][j];
                }
                else{
                    row = row+data[i][j];
                }
            }
            
            if(i != m-1){
                row = row+"},";
            }
            else{
                row = row+"}};";
            }
            
            System.out.println(row);
            row = "";
        }
        System.out.println("");
    }
}