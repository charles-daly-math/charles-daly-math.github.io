import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.geom.*;

public class InputWindow extends JPanel implements ActionListener{
    
    //Window
    Window w;

    
    //Number for the slider up and down vertically and t-value for deformation
    public double u;
    public double z;
    
    
    //Some variables defining the input window
    public static double windowsize = 300.0;
    public static double height = windowsize/4;
    
    public static JButton button1 = new JButton("Set values of (t,z)");
    
    //Sets initial values for ax+by+cz+dw = 0;
    
    
    //Sets initial value for z-slice and t-value
    public static JTextField field1 = new JTextField("4.0");
    public static JTextField field2 = new JTextField("-3.5");
    

    
    //Adding stuff to window
    public InputWindow(){
        this.setBackground(Color.WHITE);
        this.setPreferredSize(new Dimension((int) windowsize, (int) height));
        
        //Setting size of textfields
        field1.setColumns(6);
        field2.setColumns(6);
        
        //Adding text fields
        
        this.add(field1);
        this.add(field2);
        
        //Adds buttons, makes clickable
        this.add(button1);
        button1.addActionListener(this);
  
    }
    
    //Update z from Window
    public void updateZ(){
        z = w.c;
        String s = String.valueOf(z);
        if(Math.abs(z) < 0.0005){
            field2.setText("0");
        }
        else if(z > 0){
            field2.setText(s.substring(0, Math.min(s.length(), 5)));
        }
        else{
            field2.setText(s.substring(0, Math.min(s.length(), 6)));
        }
    }
    
    //Update t from Window
    public void updateT(){
        u = w.t;
        String s = String.valueOf(u);
        if(Math.abs(u) < 0.0005){
            field1.setText("0");
        }
        else if(z > 0){
            field1.setText(s.substring(0, Math.min(s.length(), 5)));
        }
        else{
            field1.setText(s.substring(0, Math.min(s.length(), 6)));
        }
    }
    
    
    //Action commands for clicking button
    public void actionPerformed(ActionEvent e){
        //Checks to see inputs are legit
        if (e.getSource() == button1){
            try{
            u = Double.parseDouble(field1.getText());
            z = Double.parseDouble(field2.getText());
            }
            
            catch (NumberFormatException nfe){
                System.out.println("Please make sure all values are doubles");
            }
    
            
            //Sets values at t and z.  
            field1.setText(String.valueOf(u));
            field2.setText(String.valueOf(z));
            

            //Sets coefficients to inputs
            w.t = u;
            w.c = z;
            
            w.repaint();
            

        }
    }
    
   
}
    
