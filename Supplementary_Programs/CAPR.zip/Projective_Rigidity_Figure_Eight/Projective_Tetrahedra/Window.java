import java.awt.*;
import java.awt.Color;
import java.awt.event.*;
import javax.swing.*;
import java.awt.geom.*;
import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

public class Window extends JPanel implements MouseListener{
    
    //Defines the affine patch by the equation ax + by + cz + dw = 1;
    public Vector P;
    
    //Variable for height of plane and tetrahedron
    public double c;
    public double t;
    public static ConvexHull ch = new ConvexHull();
    
    //Variables for generating matrices 
    public int changet = 0;
    public Matrix[][] generators;
    public Matrix[][] mats;
    public int tcounter = 0;
    public int zcounter = 0;
    
    //Variables for number of matrices, word length, and increments of t.
    public static int nom = 30000;
    public static int mdepth = 15;
    public static int tdepth = 200;
    
    //Variables for tetrahedra
    public Tetrahedron tet;
    public Tetrahedron tet2;

    
    //List of tetrahedra
    public Tetrahedron[][] tetrahedras1;
    public Tetrahedron[][] tetrahedras2;
    
    ///////////////////////////////////
    //THIS IS ALL SCREEN/WINDOW STUFF//
    ///////////////////////////////////
    
    //Some variables defining the frame
    public static double screensize = 1000.0;
    public double R;
    public Vector Org;
    
    //Adding stuff to window
    public Window(){
        this.addMouseListener(this);
        this.setBackground(Color.WHITE);
        this.setPreferredSize(new Dimension((int) screensize, (int) screensize));
    }
    
    
    
    ///////////////////////////////////
    //      JAVA COORDINATES         //
    ///////////////////////////////////
    
    
    
    //Defining java coordinates from vector coordinates
    public static double[] jc(Vector v, double s, Vector o){
        return new double[] {(((v.data[0]-o.data[0])/s)+1)*(screensize/2), (1-((v.data[1]-o.data[1])/s))*(screensize/2)};
    }
    
    //Method for telling java coordinates
    public void print(double[] jc){
        System.out.println("Java coordinates are: ("+jc[0]+","+jc[1]+")");
    }
    
    
    
    ///////////////////////////////////
    //      VECTOR COORDINATES       //
    ///////////////////////////////////
    
    
    
    //Defining vector coordinates from java coordinates
    public static Vector vc(double x, double y, double s, Vector o){
        return new Vector(new double[] {((2*x/screensize)-1)*s+o.data[0], ((-2*y/screensize)+1)*s+o.data[1]});
    }
    
    
    ////////////////////////////////////
    //THIS IS ALL DRAWING SHAPES STUFF//
    ///////////////////////////////////
    
    
    
    //Draws a line between two points in vector coordinates
    public void drawLine(Graphics2D g, Vector v, Vector w){
        g.draw(new Line2D.Double(jc(v, R, Org)[0],jc(v, R, Org)[1],jc(w, R, Org)[0],jc(w, R, Org)[1]));
    }
    
    //Draws a polygonal (closed) path between points in vector coordinates
    public void polygon(Graphics2D g, Vector[] ogvlist, Color C){
        //Takes the convex hull of the points
        Vector[] vlist = ch.hull(ogvlist);
        GeneralPath polygon = new GeneralPath(GeneralPath.WIND_EVEN_ODD,vlist.length);
        polygon.moveTo(jc(vlist[0], R, Org)[0],jc(vlist[0], R, Org)[1]);
        
        for(int i = 0; i < vlist.length; i++){
            polygon.lineTo(jc(vlist[i], R, Org)[0],jc(vlist[i], R, Org)[1]);
        }
        
        //Paints a C-colored region with black boundary
        polygon.closePath();
        g.setColor(C);
        g.fill(polygon);
        g.setColor(Color.BLACK);
        g.draw(polygon);
    }
    

    
    ///////////////////////////////////
    //THIS IS ALL FILE SPECIFIC STUFF//
    ///////////////////////////////////
    
    
    
    
    //Matrix B depending on t
    public Matrix B(double s){
        return new Matrix(new double[][] {{1.0,0.0,1.0,(3.0-s)/(s-2)},{0.0,1.0,1.0,1.0/(s-2)},{0.0,0.0,1.0,s/(2*(s-2))},{0.0,0.0,0.0,1.0}});
    }
    
    //Matrix Binv depending on t
    public Matrix Binv(double s){
        return new Matrix(new double[][] {{1.0,0.0,-1.0,3.0/2.0},{0.0,1.0,-1.0,1.0/2.0},{0.0,0.0,1.0,s/(4.0-2.0*s)},{0.0,0.0,0.0,1.0}});
    }
    
    //Matrix D depending on t
    public Matrix D(double s){
        return new Matrix(new double[][] {{1.0,0.0,0.0,0.0},{s,1.0,0.0,0.0},{2.0,1.0,1.0,0.0},{1.0,1.0,0.0,1.0}});
    }
    
    //Matrix Dinv depending on t
    public Matrix Dinv(double s){
        return new Matrix(new double[][] {{1.0,0.0,0.0,0.0},{-s,1.0,0.0,0.0},{-2.0+s,-1.0,1.0,0.0},{-1.0+s,-1.0,0.0,1.0}});
    }
    
    
    //Makes a list of generators as a function of t
    public Matrix[][] generators(double t){
        Matrix id = new Matrix(4);
        Matrix[][] aux = new Matrix[tdepth][5];
        for(int i=0; i<tdepth; i++){
            aux[i][0] = B(t+i*0.005);
            aux[i][1] = Binv(t+i*0.005);
            aux[i][2] = D(t+i*0.005);
            aux[i][3] = Dinv(t+i*0.005);
            aux[i][4] = id;
        }
        
        return aux;
    }
   

    //Makes the list of matrices
    public void makeMatrices(){
        Matrix aux = new Matrix(1);
        generators = generators(t);
        mats = aux.timedMatList(generators, nom, tdepth, mdepth);
    }
    
    
    
    //Tetrahedron 1
    public Tetrahedron tetra1(double s){ 
        return new Tetrahedron(
            new Vector(new double[] {-2.0 , 0.0, 0.0}),
                                      
            new Vector(new double[] {8.0*(-2.0+s)/(-26.0+9.0*s) , -8.0*(-4.0+s)/(-26.0+9.0*s), -16.0*(-2.0+s)/(-26.0+9.0*s)}),
                                      
            new Vector(new double[] {0.0 , -16.0/5.0 , -16.0/5.0}),
                                      
            new Vector(new double[] {
                8.0*(2.0-3.0*s+Math.pow(s,2))/(34.0-17.0*s+2*Math.pow(s,2)),
                16.0*(-3.0+s)/(34.0-17.0*s+2*Math.pow(s,2)),
                16.0*(-2.0+s)/(34.0-17.0*s+2*Math.pow(s,2))
            })
                                        ); 
    }
    
    //Tetrahedron 2
    public Tetrahedron tetra2(double s){
        return new Tetrahedron(
            new Vector(new double[] {-2.0 , 0.0, 0.0}),
                                      
            new Vector(new double[] {0.0 , -16.0/5.0, -16.0/5.0}),
                                      
            new Vector(new double[] {8.0*(1.0+s)/(-13.0+2*s) , 24.0/(2.0*s-13.0) , 16.0/(-13.0+2.0*s)}),
                                      
            new Vector(new double[] {
                8.0*(2.0-3.0*s+Math.pow(s,2))/(34.0-17.0*s+2*Math.pow(s,2)),
                16.0*(-3.0+t)/(34.0-17.0*s+2*Math.pow(s,2)),
                16.0*(-2.0+t)/(34.0-17.0*s+2*Math.pow(s,2))
            })
                                        ); 
        
        
    }
    
    
    //Paint
    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                             RenderingHints.VALUE_ANTIALIAS_ON);
   
        
        //Original tetrahedra
        tet = tetra1(t);
        tet2 = tetra2(t);

        //Makes the original tetrahedra
        if(tet.poi(tet,c).length==3 || tet.poi(tet,c).length==4){
                    polygon(g2, tet.poi(tet,c), Color.RED);
                }
        
        
        
        if(tet2.poi(tet2,c).length==3 || tet2.poi(tet2,c).length==4){
                    polygon(g2, tet2.poi(tet2,c), Color.BLUE);
                }
        

        
        /////////////////////////////////////////////////
        ///Calculates orbits of a bunch of tetrahedra ////
        /////////////////////////////////////////////////
     
        Tetrahedron testtet = new Tetrahedron();
        Vector[] points = testtet.poi(testtet, c);
        
        //Tetrahedron 1
        for(int j=0; j< nom; j++){
            testtet = tet.act(mats[tcounter][j],tet, P);
            points = tet.poi(testtet, c);
            
            if((points.length == 3) || (points.length == 4)){
                polygon(g2, points, Color.RED);
            }
        }
        
        //Tetrahedron 2
        for(int j=0; j< nom; j++){
            testtet = tet.act(mats[tcounter][j],tet2, P);
            points = tet.poi(testtet, c);
            
            if((points.length == 3) || (points.length == 4)){
                polygon(g2, points, Color.BLUE);
            }
        }
        
        
    }
    
    //Mouse commands
    public void mouseClicked(MouseEvent e){
        //Tells you where you click
        Vector v = vc(e.getX(), e.getY(), R, Org);
        Vector w = new Vector(new double[] {v.data[0], v.data[1], c});
        w.print();
    }
        
    public void mousePressed(MouseEvent e){}
    public void mouseEntered(MouseEvent e){}
    public void mouseExited(MouseEvent e){}
    public void mouseReleased(MouseEvent e){}
    
}