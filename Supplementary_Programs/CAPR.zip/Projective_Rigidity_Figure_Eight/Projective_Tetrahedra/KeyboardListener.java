import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class KeyboardListener implements KeyListener{
    
    Window w;
    InputWindow iw;
    
    public void keyPressed(KeyEvent e){
        
        
        
        //Zooms camera in/out
        if(e.getKeyCode() == KeyEvent.VK_Q){
            w.R = (2.0)*w.R;
            w.repaint();
        }
        
        if(e.getKeyCode() == KeyEvent.VK_E){
            w.R = (0.5)*w.R;
            w.repaint();
        }
        
        //Moves where the camera is WASD
        if(e.getKeyCode() == KeyEvent.VK_W){
            w.Org.data[1] = (w.R/3.0)+w.Org.data[1];
            w.repaint();
        }
        
        if(e.getKeyCode() == KeyEvent.VK_A){
            w.Org.data[0] = -(w.R/3.0)+w.Org.data[0];
            w.repaint();
        }
        
        if(e.getKeyCode() == KeyEvent.VK_D){
            w.Org.data[0] = (w.R/3.0)+w.Org.data[0];
            w.repaint();
        }
        
        if(e.getKeyCode() == KeyEvent.VK_S){
            w.Org.data[1] = -(w.R/3.0)+w.Org.data[1];
            w.repaint();
        }
        
        //Moves through level sets of height z
        if(e.getKeyCode() == KeyEvent.VK_C){
            w.zcounter = w.zcounter + 1;
            w.c = w.c + 0.05;
            iw.z = w.c;
            
            iw.updateZ();
            w.repaint();
        }
        
        if(e.getKeyCode() == KeyEvent.VK_Z){
            w.zcounter = w.zcounter - 1;
            w.c = w.c - 0.05;
            iw.z = w.c;
            
            iw.updateZ();
            w.repaint();
        }
        
        //Bumps up t
        if(e.getKeyCode() == KeyEvent.VK_T){
            if(w.t <= 4.695){
                w.tcounter = w.tcounter + 1;
                w.t = w.t+0.005;
                w.changet = 0;
            }
            iw.updateT();
            w.repaint();
        }
        
        //Bumps down t
        if(e.getKeyCode() == KeyEvent.VK_R){
            if(w.t >= 4.005){
                w.tcounter = w.tcounter - 1;
                w.t = w.t-0.005;
                w.changet = 0;
            }
            iw.updateT();
            w.repaint();
        }
        
        
        
        //Tells you where the camera and slice are at
        if(e.getKeyCode() == KeyEvent.VK_P){
            System.out.println("Origin located at: ("+w.Org.data[0]+" , "+w.Org.data[1]+")");
            System.out.println("Radius of window is: "+w.R);
            System.out.println("Height of z-slice is: "+w.c);
            System.out.println("");
            System.out.println("");
        }   
    }
    
    public void keyTyped(KeyEvent e){}
    public void keyReleased(KeyEvent e){}
    
}