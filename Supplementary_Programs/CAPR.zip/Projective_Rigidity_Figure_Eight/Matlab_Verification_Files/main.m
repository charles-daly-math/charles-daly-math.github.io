
%%%!!!ONLY UNCOMMENT AND RUN IF ABSOLUTELY SURE YOU WANT TO DELETE VARIABLES!!!
%%%clear
%%%!!!ONLY UNCOMMENT AND RUN IF ABSOLUTELY SURE YOU WANT TO DELETE VARIABLES!!!

%%%First run startup.m located in INTLAB folder to begin INTLAB.  Then
%%%after run this program.  It took approximately 24 hours to complete the
%%%full run.  

%%%%Current directory
PRFEfolderdir = fileparts(cd);

%%%%Directory to symbolic matrices
symbmatpath=fullfile(PRFEfolderdir,'Symbolic_Matlab_Matrices');

%%%%Directory to additional functions
additionalpath=fullfile(PRFEfolderdir,'Symbolic_Matlab_Matrices/additional_quantities/');

%%%%Adds paths to access symbolic matrices, additional functions
addpath(genpath(symbmatpath));
addpath(genpath(additionalpath));

%%%Formatting for interval arithemetic
format long;
intvalinit('DisplayInfsup');









%%%Loads shapes file
snapshapes = load('Snappy_Shapes.mat');

%bound on SNAPPY_shapes;
bnd = 60;

%Starting/ending positions: i in [ns1,ne1] and j in [ns2,ne2].  Helpful
%if you needed to stop the program at (i,j) = (a,b) and can start up again
%at (ns1,ne1) = (a,b+1);

ns1 = 1;
ns2 = 1;

ne1 = 60;
ne2 = 60;



%top of the string
topstr = '(p,q)       dim(H1(M);V)=1   M(p,q)-rigid   -q/p      nslope';

%write a file for top string
writelines(topstr,'rigresults.txt');

%dummy string
dummy = '';

% %adds a buffer line
% writelines(dummy,'temp.txt',WriteMode='append');

%typed rows
trows = 0;

%loop that checks if (i,j) is a goodslope and creates the .txt file
for i = ns1:ne1;
    for j = ns2:ne2;
        %checks if (i,j) is good slope.
        if(isgoodslope(i,j) == true)

            %every five rows pads with an empty row.
            if(mod(trows,5)==0)
                dummy = '';
                writelines(dummy,'rigresults.txt',WriteMode='append');
            end;

            %performs rigcheck on (i,j)
            dummy = rigcheck(i,j,snapshapes);
            % dummy = append(string(i),', ',string(j));
            

            %%adds one to the typed rows;
            trows = trows + 1;
  
            %write the data to a file so if you need to quit, you still
            %have the data of wherever you stopped.  
            writelines(dummy,'rigresults.txt',WriteMode='append');
        end
    end
end

