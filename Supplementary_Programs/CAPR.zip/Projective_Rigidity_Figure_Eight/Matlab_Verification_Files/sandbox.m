%%%SANDBOX

%%%Clears variables
clear

%%%%Current directory
PRFEfolderdir = fileparts(cd);

%%%%Directory to symbolic matrices
symbmatpath=fullfile(PRFEfolderdir,'Symbolic_Matlab_Matrices');

%%%%Directory to additional functions
additionalpath=fullfile(PRFEfolderdir,'Symbolic_Matlab_Matrices/additional_quantities/');

%%%%Adds paths to access symbolic matrices, additional functions
addpath(genpath(symbmatpath));
addpath(genpath(additionalpath));

%%%Formatting for interval arithemetic
format long;
intvalinit('DisplayInfsup');










%%%Loads shapes file
snapshapes = load('Snappy_Shapes.mat');

%%%actual shapes array
Shapes = snapshapes.Shapes;

%%%%EPS, distinct from MATLAB epsilon = 1e-19;
%%%Here EPS = 1e-15;
EPS = snapshapes.EPS;





%%%Choosing Dehn (p,q) 
dehnp=2;
dehnq=3;

%%%Accessing shapes in Shapes files.
pqShapes = Shapes{dehnp,dehnq};
z1x = infsup(pqShapes(1)-EPS,pqShapes(1)+EPS);
z1y = infsup(pqShapes(2)-EPS,pqShapes(2)+EPS);
z2x = infsup(pqShapes(3)-EPS,pqShapes(3)+EPS);
z2y = infsup(pqShapes(4)-EPS,pqShapes(4)+EPS);


%%%interval Fox derivatives of dwdx, dwdy
ndwdx = dwdx(z1x,z1y,z2x,z2y);
ndwdy = dwdy(z1x,z1y,z2x,z2y);

%top left 8x8 minor of ndwdy
tlndwdyminor = ndwdy(1:8,1:8);

%%%Checks rank of top left 8x8 minor using verifyreg command which is
%%%effectively verifylss.  Prints verified regularity, or, error depending
%%%on whether it is possible to certify the regularity of the top left 
%%%8x8 matrix.

if isregular(tlndwdyminor) == true
    fprintf('Verified regularity of top left 8x8 minor for (p,q) = ('+string(dehnp)+','+string(dehnq)+')');
    fprintf('\n');
    fprintf('\n');
else
    fprintf('ERROR: UNABLE to verify regularity of top left 8x8 minor for (p,q) = ('+string(dehnp)+','+string(dehnq)+')');
    fprintf('\n');
    fprintf('\n');
end



%%%interval vector containing au, invariant element of H0(x,l)
nau = au(z1x,z1y,z2x,z2y);

%%%first 8 coordinates of vector m solving ndwdx*nau + ndwdy*m = 0.
%%% we set the last coordinate of m to be -1.

%%%ndwdy*nau
foxandau = -ndwdx*nau;

%%%last column of ndwdy
lastcolndwdy = ndwdy(1:8,9:9);

%%%RHS to equation ndwdy*nau + ndwdy*m = 0 if assume m(9) = -1.
RHS = foxandau(1:8) + lastcolndwdy;

%%%Certified enclosure for first 8 coordinates to m satisfying
%%%ndwdx*nau + ndwdy*m = 0.
nfirst8m = verifylss(tlndwdyminor,RHS);

%%%Putting -1 on last coordinate of m;
m = [nfirst8m; infsup(-1,-1)];

%%%interval Fox derivatives of dldx, dldy
ndldx = dldx(z1x,z1y,z2x,z2y);
ndldy = dldy(z1x,z1y,z2x,z2y);

%%%interval enclosure of f(l) given f(x) living in nau and 
%%%f(y) living in m;
nfl = ndldx*nau + ndldy*m;


%%%Prints quotient of nau by nfl.
fprintf('Vector of intervals each containing the slope of the (' ...
    +string(dehnp)+','+string(dehnq)+') Dehn-filling: \n');

%nau without 4th entry, because it's zero
redvec1 = nau(1:end ~= 4);

%nfl without 4th entry, because it's zero
redvec2 = nfl(1:end ~= 4);

%vector of intervals each of which contains the true slope. 
slopeints = redvec1./redvec2;
disp(slopeints)
fprintf('\n');

%%%certified enclosure of slope of the (p,q) representation
nslope = slopebound(nau,nfl);

%%%Prints enclosure of the slope along.
fprintf('Verified enclosure of slope of representation of (' ...
    +string(dehnp)+','+string(dehnq)+') Dehn-filling: \n');
disp(nslope);
fprintf('\n');

%%%checks to see if -q/p or 0 is contained in interval.  also
%%%checks if interval is infinite.  if so, prints error
%%%otherwise, certifies rigidity for (p,q) surgery.
if ( ...
        (in(-dehnq/dehnp,nslope) == true) || ...
        (in(0,nslope) == true) || ...
        (nslope == infsup(Inf,Inf)) ...
    )
    fprintf('ERROR: UNABLE to verify rigidity of (p,q) = ('+string(dehnp)+','+string(dehnq)+') Dehn-filling.');
    fprintf('\n');
    fprintf('\n');
else
    fprintf('Verified rigidity of (p,q) = ('+string(dehnp)+','+string(dehnq)+') Dehn-filling.');
    fprintf('\n');
    fprintf('\n');
end

%%%%%%%%%%%%%%%%Performs a rigcheck on (p,q).
fprintf('Results of rigcheck on (p,q) = ('+string(dehnp)+','+string(dehnq)+') Dehn-filling.');
fprintf('\n');
fprintf(rigcheck(dehnp,dehnq,snapshapes));
fprintf('\n');

