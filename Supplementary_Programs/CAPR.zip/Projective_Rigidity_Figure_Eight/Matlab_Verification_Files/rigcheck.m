%%%Function that inputs (p,q) Dehn filling, and the Snappy_Shapes data
%%%which we are calling data.  Including data argument into the function 
%%%because otherwise Matlab would have to load('Snappy_Shapes.mat') each
%%%call of rigcheck.

%%%Produce a vector B which consists of 5 strings B = 
%%% [intpair,rankcheck,slopecheck,strnratio,strnslope]
%
%%%intpair = "(p,q)"
%
%%%rankcheck = true if ndwdy top left 8x8 minor is non-singular, false
%%%otherwise
%
%%%slopecheck = true if -q/p is outside the certified slope bound nslope
%%%and false otherwise, or false because rankcheck was false
%
%%%strnslope is a certified bound on the slope of the (p,q) representation
%%%provided rankcheck = true.  If rankcheck = false, then strnslope = (NaN,NaN)
%%%and slopecheck = false.

function B = rigcheck(intp, intq, data)

    %%%Shapes data and EPS from Snappy_Shapes.mat
    Shapes = data.Shapes;
    EPS = data.EPS;

    %%%Accessing shapes in Shapes files.
    intpair = '('+string(intp)+','+string(intq)+')';
    pqShapes = Shapes{intp,intq};

    z1x = infsup(pqShapes(1)-EPS,pqShapes(1)+EPS);
    z1y = infsup(pqShapes(2)-EPS,pqShapes(2)+EPS);
    z2x = infsup(pqShapes(3)-EPS,pqShapes(3)+EPS);
    z2y = infsup(pqShapes(4)-EPS,pqShapes(4)+EPS);

    %%%write the ratio of p/q as a string
    strnratio = sprintf('%0.6f', -intq/intp);
    strnratio = strnratio(1:end-1);

    %%%interval Fox derivatives of dwdx, dwdy
    ndwdx = dwdx(z1x,z1y,z2x,z2y);
    ndwdy = dwdy(z1x,z1y,z2x,z2y);

    %top left 8x8 minor of ndwdy
    tlndwdyminor = ndwdy(1:8,1:8);

    %%%Checks rank of top left 8x8 minor using verifyreg command which is
    %%%effectively verifylss.  Prints verified regularity, or, error depending
    %%%on whether it is possible to certify the regularity of the top left 
    %%%8x8 matrix.
    rankcheck = logical(isregular(tlndwdyminor));

    %%%%%If rankcheck is false, sets slopecheck to false, nslope to (NaN,NaN)
    %%% and exits routine 
    if rankcheck == false
        slopecheck = false;
        strnslope = '(NaN,NaN)';
        B = append(intpair,'     ',string(rankcheck),'     ',string(slopecheck),'     ',strnratio,'     ',strnslope);
        return;
    end


    %%%interval vector containing au, invariant element of H0(x,l)
    nau = au(z1x,z1y,z2x,z2y);

    %%%first 8 coordinates of vector m solving ndwdx*nau + ndwdy*m = 0.
    %%% we set the last coordinate of m to be -1.

    %%%ndwdy*nau
    foxandau = -ndwdx*nau;

    %%%last column of ndwdy
    lastcolndwdy = ndwdy(1:8,9:9);

    %%%RHS to equation ndwdy*nau + ndwdy*m = 0 if assume m(9) = -1.
    RHS = foxandau(1:8) + lastcolndwdy;

    %%%Certified enclosure for first 8 coordinates to m satisfying
    %%%ndwdx*nau + ndwdy*m = 0.
    nfirst8m = verifylss(tlndwdyminor,RHS);

    %%%Putting -1 on last coordinate of m;
    m = [nfirst8m; infsup(-1,-1)];

    %%%interval Fox derivatives of dldx, dldy
    ndldx = dldx(z1x,z1y,z2x,z2y);
    ndldy = dldy(z1x,z1y,z2x,z2y);

    %%%interval enclosure of f(l) given f(x) living in nau and 
    %%%f(y) living in m;
    nfl = ndldx*nau + ndldy*m;

    %%%certified enclosure of slope of the (p,q) representation
    nslope = slopebound(nau,nfl);
    strnslope = '('+string(inf(nslope))+', '+string(sup(nslope))+')';

    %%%if nslope is infinite OR if nslope contains 0, returns false.  
    %%%otherwise, nslope is finite AND doesn't contain 0.  nslope is then
    %%%TRUE if -q/p is NOT in nslope and FALSE if -q/p is in nslope.  
    
    if ((nslope == infsup(Inf,Inf)) || in(0,nslope))
        slopecheck = false;
    else
        slopecheck = ~in(-intq/intp,nslope);
    end

    %%%Returns [[p,q], true/false for rankcheck, 
    %%%true/false for slopecheck, and the slope bound itself
    % B = [intpair,rankcheck,slopecheck,strnratio,strnslope];
    B = append(intpair,'     ',string(rankcheck),'     ',string(slopecheck),'     ',strnratio,'     ',strnslope);
end


