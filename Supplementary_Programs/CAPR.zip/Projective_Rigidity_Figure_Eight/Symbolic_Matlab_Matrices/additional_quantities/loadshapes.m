%%%function that makes the shapes from SnapPy accessible.

function data = loadshapes()
    data = load('Snappy_Shapes.mat');
end