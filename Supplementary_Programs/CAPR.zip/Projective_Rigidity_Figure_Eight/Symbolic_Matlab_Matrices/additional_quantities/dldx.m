%%%%Fox derivative dldx

function B = dldx(z1x, z1y, z2x, z2y)
    part1 = -YinvX(z1x, z1y, z2x, z2y);
    part2 = YinvXinvY(z1x, z1y, z2x, z2y);
    part3 = YinvXinvYX(z1x, z1y, z2x, z2y);
    part4 = -(YinvXinvYX(z1x, z1y, z2x, z2y))*(XinvYinvX(z1x, z1y, z2x, z2y));

    B = part1 + part2 + part3 + part4;
end