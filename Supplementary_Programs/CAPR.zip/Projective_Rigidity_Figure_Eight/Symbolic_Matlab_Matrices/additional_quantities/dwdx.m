%%%%Fox derivative dwx

function B = dwdx(z1x, z1y, z2x, z2y)
    IID = infsup(eye(9),eye(9));
    part2 = -XinvYinvX(z1x, z1y, z2x, z2y);
    part3 = XinvYinvXY(z1x, z1y, z2x, z2y);
    part4 = YXinvYinvX(z1x, z1y, z2x, z2y);
    part5 = -Ymat(z1x, z1y, z2x, z2y);

    B = IID + part2 + part3 + part4 + part5;
end