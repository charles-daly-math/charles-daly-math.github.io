%%%%%%Routine to take in two vectors nau and nfl, and determine
% if -q,p is in the ratio of the entries of nau/nfl.  Note that by
%defintion, nau = (slope)*nfl, so slope is an element of EACH interval
%nau(i)/nfl(i) for each i where nfl(i) != 0.  We intersect over all 
%non-zero intervals nau(i)/nfl(i) to obtain a certified containment of
%where slope must live.
% 

function B = slopebound(vec1,vec2)

%nau without 4th entry, because it's zero
redvec1 = vec1(1:end ~= 4);

%nfl without 4th entry, because it's zero
redvec2 = vec2(1:end ~= 4);

%vector of intervals each of which contains the true slope.  Note certain
%intervals could contain (-infinity, infinity).
slopeints = redvec1./redvec2;

%taking the infinte value intervals
slopeints = slopeints(isfinite(slopeints));

%if there are no finite values, returns (Inf,Inf) interval and exits
%function.
if isempty(slopeints) == true
    B = infsup(Inf,Inf);
    return;
end

%upper bounds of each interval
uppbnds = sup(slopeints);

%lower bounds of each interval
lowbnds = inf(slopeints);

%taking the smallest lower bound, and largest lower bound for tightest
%interval constraint certifying where slope lives.
B = infsup(max(lowbnds),min(uppbnds));

end