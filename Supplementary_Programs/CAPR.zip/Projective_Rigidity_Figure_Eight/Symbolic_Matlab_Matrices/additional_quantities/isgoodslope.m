%%%function that checks if (i,j) is a good slope where good means not
%%an exceptional slope.

function B = isgoodslope(i,j)

%%%%GCD = 1 test
gcdtest = isequal(gcd(i,j),1);

%not an exceptional slope test;
% oneone = not(isequal([i,j],[1,1]));
twoone = not(isequal([i,j],[2,1]));
threeone = not(isequal([i,j],[3,1]));
fourone = not(isequal([i,j],[4,1]));

% t1 = oneone & twoone & threeone & fourone;
t1 = twoone & threeone & fourone;

%positive natural less than 61.
p1l = 0 < i;
p1u = i < 61;

p2l = 0 < j;
p2u = j < 61;

t2 = p1l & p1u & p2l & p2u;

%tests all conditions
B = gcdtest & t1 & t2;

end