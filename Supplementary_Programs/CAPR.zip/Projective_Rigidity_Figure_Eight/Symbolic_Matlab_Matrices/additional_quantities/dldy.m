%%%%Fox derivative dldy

function B = dldy(z1x, z1y, z2x, z2y)
    IID = infsup(eye(9),eye(9));
    part2 = - YinvXinvY(z1x, z1y, z2x, z2y);
    part3 = -(YinvXinvYX(z1x, z1y, z2x, z2y))*(XinvY(z1x, z1y, z2x, z2y));
    part4 = (YinvXinvYX(z1x, z1y, z2x, z2y))*(XinvYinvX(z1x, z1y, z2x, z2y));

    B = IID + part2 + part3 + part4;
end